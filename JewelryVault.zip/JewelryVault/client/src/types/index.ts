export interface User {
  id: number;
  username: string;
  email: string;
  firstName?: string;
  lastName?: string;
  phone?: string;
  address?: string;
  city?: string;
  state?: string;
  zip?: string;
  country?: string;
  createdAt: Date;
}

export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  categoryId: number;
  images: string[];
  featured: boolean;
  new: boolean;
  rating: number;
  reviewCount: number;
  stock: number;
  variants: ProductVariants | null;
  createdAt: Date;
}

export interface ProductVariants {
  sizes?: string[];
  colors?: string[];
  chainLength?: string[];
  length?: string[];
  [key: string]: string[] | undefined;
}

export interface Category {
  id: number;
  name: string;
  slug: string;
  image: string;
}

export interface CartItem {
  id: number;
  userId: number;
  productId: number;
  quantity: number;
  variant?: string;
  createdAt: Date;
  product?: Product;
}

export interface WishlistItem {
  id: number;
  userId: number;
  productId: number;
  createdAt: Date;
  product?: Product;
}

export interface OrderItem {
  productId: number;
  name: string;
  price: number;
  quantity: number;
  variant?: string;
  image: string;
}

export interface ShippingAddress {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  country: string;
}

export interface Order {
  id: number;
  userId: number;
  total: number;
  status: string;
  shippingAddress: ShippingAddress;
  items: OrderItem[];
  createdAt: Date;
}

export interface Testimonial {
  id: number;
  name: string;
  location: string;
  content: string;
  rating: number;
  avatar: string | null;
  featured: boolean;
}
