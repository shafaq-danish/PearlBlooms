import React, { createContext, useState, useEffect, useCallback } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { useAuth } from './AuthContext';
import { CartItem, Product } from '@/types';
import { useToast } from '@/hooks/use-toast';
import { queryClient } from '@/lib/queryClient';

interface CartContextProps {
  cartItems: CartItem[];
  isLoading: boolean;
  addToCart: (productId: number, quantity?: number, variant?: string) => Promise<void>;
  removeFromCart: (itemId: number) => Promise<void>;
  updateCartItemQuantity: (itemId: number, quantity: number) => Promise<void>;
  clearCart: () => Promise<void>;
  getCartTotal: () => number;
}

export const CartContext = createContext<CartContextProps>({
  cartItems: [],
  isLoading: false,
  addToCart: async () => {},
  removeFromCart: async () => {},
  updateCartItemQuantity: async () => {},
  clearCart: async () => {},
  getCartTotal: () => 0,
});

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const { user } = useAuth();
  const { toast } = useToast();

  const fetchCartItems = useCallback(async () => {
    if (!user) {
      setCartItems([]);
      return;
    }

    try {
      setIsLoading(true);
      const res = await fetch('/api/cart', {
        credentials: 'include',
      });
      
      if (res.ok) {
        const data = await res.json();
        setCartItems(data);
      } else if (res.status === 401) {
        setCartItems([]);
      } else {
        throw new Error('Failed to fetch cart items');
      }
    } catch (error) {
      console.error('Error fetching cart items:', error);
      toast({
        title: 'Error',
        description: 'Failed to load your cart items',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }, [user, toast]);

  useEffect(() => {
    fetchCartItems();
  }, [fetchCartItems]);

  const addToCart = async (productId: number, quantity: number = 1, variant?: string) => {
    if (!user) {
      toast({
        title: 'Please login',
        description: 'You need to be logged in to add items to your cart',
        variant: 'destructive',
      });
      return;
    }

    try {
      setIsLoading(true);
      const res = await apiRequest('POST', '/api/cart', {
        productId,
        quantity,
        variant,
      });
      
      const newItem = await res.json();
      
      // Check if item already exists to update or add
      const existingItemIndex = cartItems.findIndex(item => item.id === newItem.id);
      
      if (existingItemIndex >= 0) {
        const updatedItems = [...cartItems];
        updatedItems[existingItemIndex] = newItem;
        setCartItems(updatedItems);
      } else {
        setCartItems([...cartItems, newItem]);
      }
      
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      
      toast({
        title: 'Added to cart',
        description: `${newItem.product.name} has been added to your cart`,
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to add item to cart',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const removeFromCart = async (itemId: number) => {
    try {
      setIsLoading(true);
      await apiRequest('DELETE', `/api/cart/${itemId}`, undefined);
      
      setCartItems(cartItems.filter(item => item.id !== itemId));
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      
      toast({
        title: 'Removed from cart',
        description: 'Item has been removed from your cart',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to remove item from cart',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const updateCartItemQuantity = async (itemId: number, quantity: number) => {
    try {
      setIsLoading(true);
      const res = await apiRequest('PUT', `/api/cart/${itemId}`, { quantity });
      
      const updatedItem = await res.json();
      setCartItems(cartItems.map(item => item.id === itemId ? updatedItem : item));
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update cart item quantity',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const clearCart = async () => {
    try {
      setIsLoading(true);
      await apiRequest('DELETE', '/api/cart', undefined);
      
      setCartItems([]);
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      
      toast({
        title: 'Cart cleared',
        description: 'All items have been removed from your cart',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to clear cart',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getCartTotal = () => {
    return cartItems.reduce((total, item) => 
      total + (item.product?.price || 0) * item.quantity, 0
    );
  };

  return (
    <CartContext.Provider
      value={{
        cartItems,
        isLoading,
        addToCart,
        removeFromCart,
        updateCartItemQuantity,
        clearCart,
        getCartTotal,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};
