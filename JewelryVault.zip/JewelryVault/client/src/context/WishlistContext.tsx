import React, { createContext, useState, useEffect, useCallback } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { useAuth } from './AuthContext';
import { WishlistItem } from '@/types';
import { useToast } from '@/hooks/use-toast';
import { queryClient } from '@/lib/queryClient';

interface WishlistContextProps {
  wishlistItems: WishlistItem[];
  isLoading: boolean;
  addToWishlist: (productId: number) => Promise<void>;
  removeFromWishlist: (itemId: number) => Promise<void>;
  isInWishlist: (productId: number) => boolean;
}

export const WishlistContext = createContext<WishlistContextProps>({
  wishlistItems: [],
  isLoading: false,
  addToWishlist: async () => {},
  removeFromWishlist: async () => {},
  isInWishlist: () => false,
});

export const WishlistProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [wishlistItems, setWishlistItems] = useState<WishlistItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const { user } = useAuth();
  const { toast } = useToast();

  const fetchWishlistItems = useCallback(async () => {
    if (!user) {
      setWishlistItems([]);
      return;
    }

    try {
      setIsLoading(true);
      const res = await fetch('/api/wishlist', {
        credentials: 'include',
      });
      
      if (res.ok) {
        const data = await res.json();
        setWishlistItems(data);
      } else if (res.status === 401) {
        setWishlistItems([]);
      } else {
        throw new Error('Failed to fetch wishlist items');
      }
    } catch (error) {
      console.error('Error fetching wishlist items:', error);
      toast({
        title: 'Error',
        description: 'Failed to load your wishlist items',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }, [user, toast]);

  useEffect(() => {
    fetchWishlistItems();
  }, [fetchWishlistItems]);

  const addToWishlist = async (productId: number) => {
    if (!user) {
      toast({
        title: 'Please login',
        description: 'You need to be logged in to add items to your wishlist',
        variant: 'destructive',
      });
      return;
    }
    
    // Check if product is already in wishlist
    if (isInWishlist(productId)) {
      toast({
        title: 'Already in wishlist',
        description: 'This item is already in your wishlist',
      });
      return;
    }

    try {
      setIsLoading(true);
      const res = await apiRequest('POST', '/api/wishlist', { productId });
      
      const newItem = await res.json();
      setWishlistItems([...wishlistItems, newItem]);
      queryClient.invalidateQueries({ queryKey: ['/api/wishlist'] });
      
      toast({
        title: 'Added to wishlist',
        description: `${newItem.product.name} has been added to your wishlist`,
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to add item to wishlist',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const removeFromWishlist = async (itemId: number) => {
    try {
      setIsLoading(true);
      await apiRequest('DELETE', `/api/wishlist/${itemId}`, undefined);
      
      setWishlistItems(wishlistItems.filter(item => item.id !== itemId));
      queryClient.invalidateQueries({ queryKey: ['/api/wishlist'] });
      
      toast({
        title: 'Removed from wishlist',
        description: 'Item has been removed from your wishlist',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to remove item from wishlist',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const isInWishlist = (productId: number): boolean => {
    return wishlistItems.some(item => item.productId === productId);
  };

  return (
    <WishlistContext.Provider
      value={{
        wishlistItems,
        isLoading,
        addToWishlist,
        removeFromWishlist,
        isInWishlist,
      }}
    >
      {children}
    </WishlistContext.Provider>
  );
};
