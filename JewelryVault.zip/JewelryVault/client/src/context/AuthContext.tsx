import React, { createContext, useState, useContext, useCallback } from 'react';
import { useLocation } from 'wouter';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { User } from '@/types';

interface AuthContextProps {
  user: User | null;
  isLoading: boolean;
  error: string | null;
  login: (username: string, password: string) => Promise<void>;
  register: (userData: RegisterData) => Promise<void>;
  logout: () => Promise<void>;
  fetchUser: () => Promise<void>;
  updateUser: (userData: Partial<RegisterData>) => Promise<void>;
}

interface RegisterData {
  username: string;
  password: string;
  email: string;
  firstName?: string;
  lastName?: string;
  phone?: string;
  address?: string;
  city?: string;
  state?: string;
  zip?: string;
  country?: string;
}

const AuthContext = createContext<AuthContextProps>({
  user: null,
  isLoading: false,
  error: null,
  login: async () => {},
  register: async () => {},
  logout: async () => {},
  fetchUser: async () => {},
  updateUser: async () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const fetchUser = useCallback(async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/auth/me', {
        credentials: 'include',
      });

      if (res.ok) {
        const userData = await res.json();
        setUser(userData);
      } else {
        setUser(null);
      }
    } catch (error) {
      console.error('Error fetching user:', error);
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const login = async (username: string, password: string) => {
    try {
      setIsLoading(true);
      setError(null);
      
      const res = await apiRequest('POST', '/api/auth/login', { username, password });
      const userData = await res.json();
      
      setUser(userData);
      toast({
        title: 'Welcome back!',
        description: `You're now logged in as ${userData.username}`,
      });
      setLocation('/');
    } catch (err) {
      const error = err as Error;
      setError(error.message || 'Failed to login. Please try again.');
      toast({
        title: 'Login failed',
        description: error.message || 'Invalid username or password',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (userData: RegisterData) => {
    try {
      setIsLoading(true);
      setError(null);
      
      const res = await apiRequest('POST', '/api/auth/register', userData);
      const newUser = await res.json();
      
      setUser(newUser);
      toast({
        title: 'Registration successful!',
        description: 'Your account has been created successfully.',
      });
      setLocation('/');
    } catch (err) {
      const error = err as Error;
      setError(error.message || 'Failed to register. Please try again.');
      toast({
        title: 'Registration failed',
        description: error.message || 'Please check your information and try again',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      setIsLoading(true);
      await apiRequest('POST', '/api/auth/logout', {});
      setUser(null);
      toast({
        title: 'Logged out',
        description: 'You have been successfully logged out.',
      });
      setLocation('/');
    } catch (err) {
      const error = err as Error;
      toast({
        title: 'Logout failed',
        description: error.message || 'There was an error logging out',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const updateUser = async (userData: Partial<RegisterData>) => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Implement when API is ready
      // const res = await apiRequest('PATCH', '/api/auth/profile', userData);
      // const updatedUser = await res.json();
      
      // setUser(updatedUser);
      toast({
        title: 'Profile updated',
        description: 'Your profile has been updated successfully.',
      });
    } catch (err) {
      const error = err as Error;
      setError(error.message || 'Failed to update profile. Please try again.');
      toast({
        title: 'Update failed',
        description: error.message || 'There was an error updating your profile',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        error,
        login,
        register,
        logout,
        fetchUser,
        updateUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
