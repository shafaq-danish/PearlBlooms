import Hero from "@/components/home/Hero";
import FeaturedCategories from "@/components/home/FeaturedCategories";
import NewCollection from "@/components/home/NewCollection";
import CollectionStory from "@/components/home/CollectionStory";
import Testimonials from "@/components/home/Testimonials";
import FeatureHighlights from "@/components/home/FeatureHighlights";
import InstagramFeed from "@/components/home/InstagramFeed";
import Newsletter from "@/components/layout/Newsletter";
import { Helmet } from "react-helmet";

const HomePage = () => {
  return (
    <>
      <Helmet>
        <title>LUMIÈRE | Luxury Jewelry Collection</title>
        <meta name="description" content="Discover our exquisite collection of handcrafted luxury jewelry. Timeless elegance reimagined with rings, necklaces, earrings, and bracelets made from the finest materials." />
      </Helmet>
      
      <Hero />
      <FeaturedCategories />
      <NewCollection />
      <CollectionStory />
      <Testimonials />
      <FeatureHighlights />
      <InstagramFeed />
      <Newsletter />
    </>
  );
};

export default HomePage;
