import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { Category } from "@/types";
import ProductList from "@/components/product/ProductList";
import { Helmet } from "react-helmet";

const ProductsPage = () => {
  const { categorySlug } = useParams();
  
  const { data: categories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  const category = categories?.find(c => c.slug === categorySlug);
  const categoryId = category?.id;
  
  const title = category 
    ? `${category.name} Collection` 
    : categorySlug 
      ? `${categorySlug.charAt(0).toUpperCase() + categorySlug.slice(1)} Collection`
      : "All Collections";

  return (
    <>
      <Helmet>
        <title>{title} | LUMIÈRE Jewelry</title>
        <meta name="description" content={`Explore our exclusive ${title.toLowerCase()}. Handcrafted luxury jewelry designed with precision and passion for timeless elegance.`} />
      </Helmet>
    
      <div className="container mx-auto px-4 py-12">
        <header className="mb-12 text-center">
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4">{title}</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Discover our exclusive collection of handcrafted pieces that combine timeless design with exceptional quality.
          </p>
        </header>
        
        <ProductList 
          categoryId={categoryId} 
          title="" 
          showFilters={true}
        />
      </div>
    </>
  );
};

export default ProductsPage;
