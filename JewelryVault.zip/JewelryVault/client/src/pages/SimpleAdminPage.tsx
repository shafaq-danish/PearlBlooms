import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Product, Category } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { formatCurrency } from '@/lib/utils';

export default function SimpleAdminPage() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('products');
  const [editProduct, setEditProduct] = useState<Product | null>(null);
  const [addMode, setAddMode] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: 0,
    categoryId: 1,
    stock: 0,
    featured: false,
    new: false,
    imageUrl: ''
  });

  // Fetch products
  const { data: products, isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  // Fetch categories
  const { data: categories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  // Update product mutation
  const updateProductMutation = useMutation({
    mutationFn: async (product: Partial<Product>) => {
      return apiRequest(`/api/products/${product.id}`, {
        method: 'PATCH',
        body: JSON.stringify(product)
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      setEditProduct(null);
      toast({
        title: "Success!",
        description: "Your product has been updated successfully.",
      });
    },
    onError: (error) => {
      console.error('Update error:', error);
      toast({
        title: "Oh no!",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Add product mutation
  const addProductMutation = useMutation({
    mutationFn: async (product: any) => {
      return apiRequest('/api/products', {
        method: 'POST',
        body: JSON.stringify(product)
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      resetForm();
      setAddMode(false);
      toast({
        title: "Success!",
        description: "Your new product has been added to the store.",
      });
    },
    onError: (error) => {
      console.error('Add error:', error);
      toast({
        title: "Oh no!",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Delete product mutation
  const deleteProductMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/products/${id}`, {
        method: 'DELETE'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      toast({
        title: "Product deleted",
        description: "The product has been removed from your store.",
      });
    },
    onError: (error) => {
      console.error('Delete error:', error);
      toast({
        title: "Error",
        description: "Could not delete the product. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else if (type === 'number') {
      setFormData(prev => ({ ...prev, [name]: Number(value) }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleEditChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    if (!editProduct) return;
    
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setEditProduct({ ...editProduct, [name]: checked });
    } else if (type === 'number') {
      setEditProduct({ ...editProduct, [name]: Number(value) });
    } else {
      setEditProduct({ ...editProduct, [name]: value });
    }
  };

  const handleAddProduct = () => {
    const newProduct = {
      ...formData,
      images: [formData.imageUrl],
      variants: null
    };
    
    delete newProduct.imageUrl;
    addProductMutation.mutate(newProduct);
  };

  const handleUpdateProduct = () => {
    if (!editProduct) return;
    updateProductMutation.mutate(editProduct);
  };

  const handleDeleteProduct = (id: number) => {
    if (window.confirm('Are you sure you want to delete this product?')) {
      deleteProductMutation.mutate(id);
    }
  };

  const startEdit = (product: Product) => {
    setEditProduct(product);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      price: 0,
      categoryId: 1,
      stock: 0,
      featured: false,
      new: false,
      imageUrl: ''
    });
  };

  // Display loading state
  if (productsLoading) {
    return <div className="flex items-center justify-center h-screen">Loading admin panel...</div>;
  }

  return (
    <div className="container py-8">
      <Helmet>
        <title>Simple Admin | Pearl Blooms</title>
        <meta name="description" content="Manage your store products easily" />
      </Helmet>

      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Pearl Blooms Admin</h1>
        <Button onClick={() => { setAddMode(!addMode); resetForm(); }}>
          {addMode ? 'Cancel' : 'Add New Product'}
        </Button>
      </div>

      {addMode && (
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Add New Product</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Product Name</label>
                  <Input 
                    name="name" 
                    value={formData.name} 
                    onChange={handleInputChange} 
                    placeholder="Pearl Drop Earrings"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Price ($)</label>
                  <Input 
                    type="number" 
                    name="price" 
                    value={formData.price} 
                    onChange={handleInputChange} 
                    placeholder="99.99"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Category</label>
                  <Select 
                    name="categoryId" 
                    value={String(formData.categoryId)} 
                    onValueChange={(value) => setFormData(prev => ({ ...prev, categoryId: Number(value) }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories?.map(category => (
                        <SelectItem key={category.id} value={String(category.id)}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Stock</label>
                  <Input 
                    type="number" 
                    name="stock" 
                    value={formData.stock} 
                    onChange={handleInputChange} 
                    placeholder="10"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Main Image URL</label>
                  <Input 
                    name="imageUrl" 
                    value={formData.imageUrl} 
                    onChange={handleInputChange} 
                    placeholder="https://example.com/image.jpg"
                  />
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Description</label>
                  <Textarea 
                    name="description" 
                    value={formData.description} 
                    onChange={handleInputChange} 
                    rows={5}
                    placeholder="Beautiful pearl earrings with..."
                  />
                </div>
                
                <div className="flex items-center space-x-2 mt-4">
                  <input
                    type="checkbox"
                    id="featured"
                    name="featured"
                    checked={formData.featured}
                    onChange={handleInputChange}
                    className="h-4 w-4"
                  />
                  <label htmlFor="featured" className="text-sm font-medium">
                    Feature on homepage
                  </label>
                </div>
                
                <div className="flex items-center space-x-2 mt-2">
                  <input
                    type="checkbox"
                    id="new"
                    name="new"
                    checked={formData.new}
                    onChange={handleInputChange}
                    className="h-4 w-4"
                  />
                  <label htmlFor="new" className="text-sm font-medium">
                    Mark as new product
                  </label>
                </div>
                
                <div className="pt-4">
                  {formData.imageUrl && (
                    <div className="mt-2">
                      <p className="text-sm font-medium mb-1">Image Preview:</p>
                      <img 
                        src={formData.imageUrl} 
                        alt="Product preview" 
                        className="w-full h-40 object-cover rounded-md"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = 'https://placehold.co/300x200?text=Image+Not+Found';
                        }}
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <div className="flex justify-end mt-6">
              <Button 
                onClick={handleAddProduct} 
                disabled={!formData.name || !formData.description || !formData.imageUrl}
              >
                Add Product to Store
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {editProduct && (
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Edit Product</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Product Name</label>
                  <Input 
                    name="name" 
                    value={editProduct.name} 
                    onChange={handleEditChange} 
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Price ($)</label>
                  <Input 
                    type="number" 
                    name="price" 
                    value={editProduct.price} 
                    onChange={handleEditChange} 
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Category</label>
                  <Select 
                    value={String(editProduct.categoryId)} 
                    onValueChange={(value) => setEditProduct({...editProduct, categoryId: Number(value)})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories?.map(category => (
                        <SelectItem key={category.id} value={String(category.id)}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Stock</label>
                  <Input 
                    type="number" 
                    name="stock" 
                    value={editProduct.stock} 
                    onChange={handleEditChange} 
                  />
                </div>
                
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="edit-featured"
                    name="featured"
                    checked={editProduct.featured}
                    onChange={handleEditChange}
                    className="h-4 w-4"
                  />
                  <label htmlFor="edit-featured" className="text-sm font-medium">
                    Feature on homepage
                  </label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="edit-new"
                    name="new"
                    checked={editProduct.new}
                    onChange={handleEditChange}
                    className="h-4 w-4"
                  />
                  <label htmlFor="edit-new" className="text-sm font-medium">
                    Mark as new product
                  </label>
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Description</label>
                  <Textarea 
                    name="description" 
                    value={editProduct.description} 
                    onChange={handleEditChange} 
                    rows={5}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Current Images</label>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    {editProduct.images.map((img, index) => (
                      <div key={index} className="relative group">
                        <img 
                          src={img} 
                          alt={`Product ${index + 1}`} 
                          className="w-full h-24 object-cover rounded"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src = 'https://placehold.co/300x200?text=Image+Not+Found';
                          }}
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex justify-between mt-6">
              <Button variant="outline" onClick={() => setEditProduct(null)}>
                Cancel
              </Button>
              <Button onClick={handleUpdateProduct}>
                Save Changes
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="w-full">
          <TabsTrigger value="products" className="flex-1">Products</TabsTrigger>
          <TabsTrigger value="categories" className="flex-1">Categories</TabsTrigger>
          <TabsTrigger value="orders" className="flex-1">Orders</TabsTrigger>
        </TabsList>
        
        <TabsContent value="products" className="pt-6">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[80px]">Image</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Stock</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {products?.map(product => (
                  <TableRow key={product.id}>
                    <TableCell>
                      <img 
                        src={product.images[0]} 
                        alt={product.name}
                        className="w-16 h-16 object-cover rounded" 
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = 'https://placehold.co/80x80?text=No+Image';
                        }}
                      />
                    </TableCell>
                    <TableCell className="font-medium">{product.name}</TableCell>
                    <TableCell>{formatCurrency(product.price)}</TableCell>
                    <TableCell>
                      {categories?.find(c => c.id === product.categoryId)?.name}
                    </TableCell>
                    <TableCell>
                      <span className={product.stock < 5 ? 'text-red-500 font-medium' : ''}>
                        {product.stock}
                      </span>
                    </TableCell>
                    <TableCell>
                      {product.featured && <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded mr-1">Featured</span>}
                      {product.new && <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">New</span>}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="sm" className="mr-2" onClick={() => startEdit(product)}>
                        Edit
                      </Button>
                      <Button variant="destructive" size="sm" onClick={() => handleDeleteProduct(product.id)}>
                        Delete
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}

                {products && products.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                      No products found. Add your first product!
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
        
        <TabsContent value="categories" className="pt-6">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[80px]">Image</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Slug</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {categories?.map(category => (
                  <TableRow key={category.id}>
                    <TableCell>
                      <img 
                        src={category.image} 
                        alt={category.name}
                        className="w-12 h-12 object-cover rounded" 
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = 'https://placehold.co/80x80?text=No+Image';
                        }}
                      />
                    </TableCell>
                    <TableCell className="font-medium">{category.name}</TableCell>
                    <TableCell>{category.slug}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="sm">
                        Edit
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
        
        <TabsContent value="orders" className="pt-6">
          <div className="bg-gray-50 rounded-lg p-8 text-center">
            <h3 className="text-xl font-medium mb-2">Order Management</h3>
            <p className="text-muted-foreground">
              Order management features coming soon!
            </p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}