import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { Order } from "@/types";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatCurrency } from "@/lib/utils";
import { Helmet } from "react-helmet";

const AccountPage = () => {
  const [, setLocation] = useLocation();
  const { user, logout, isLoading: authLoading } = useAuth();
  const [activeTab, setActiveTab] = useState("profile");
  
  const { data: orders, isLoading: ordersLoading } = useQuery<Order[]>({
    queryKey: ['/api/orders'],
    enabled: !!user,
  });
  
  if (!user && !authLoading) {
    return (
      <>
        <Helmet>
          <title>Account | LUMIÈRE Jewelry</title>
          <meta name="description" content="Manage your account, view order history, and update your profile details." />
        </Helmet>
      
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-2xl mx-auto text-center">
            <h1 className="text-3xl md:text-4xl font-serif font-bold mb-4">Account</h1>
            <p className="text-gray-600 mb-8">Please log in to view your account</p>
            <Button onClick={() => setLocation('/login?redirect=account')}>
              Login to Continue
            </Button>
          </div>
        </div>
      </>
    );
  }
  
  return (
    <>
      <Helmet>
        <title>My Account | LUMIÈRE Jewelry</title>
        <meta name="description" content="Manage your account, view order history, and update your profile details." />
      </Helmet>
    
      <div className="container mx-auto px-4 py-12">
        <h1 className="text-3xl md:text-4xl font-serif font-bold mb-8">My Account</h1>
        
        <div className="bg-white rounded-lg shadow-sm">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <div className="px-6 pt-6">
              <TabsList className="grid grid-cols-3 w-full max-w-md">
                <TabsTrigger value="profile">Profile</TabsTrigger>
                <TabsTrigger value="orders">Orders</TabsTrigger>
                <TabsTrigger value="settings">Settings</TabsTrigger>
              </TabsList>
            </div>
            
            <TabsContent value="profile" className="p-6">
              <div className="max-w-3xl">
                <h2 className="text-2xl font-medium mb-6">Profile Information</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div>
                    <div className="mb-6">
                      <h3 className="text-sm font-medium text-gray-500 mb-1">Username</h3>
                      <p className="font-medium">{user?.username}</p>
                    </div>
                    
                    <div className="mb-6">
                      <h3 className="text-sm font-medium text-gray-500 mb-1">Email</h3>
                      <p className="font-medium">{user?.email}</p>
                    </div>
                    
                    <div className="mb-6">
                      <h3 className="text-sm font-medium text-gray-500 mb-1">Full Name</h3>
                      <p className="font-medium">
                        {user?.firstName ? `${user.firstName} ${user.lastName || ''}` : 'Not provided'}
                      </p>
                    </div>
                  </div>
                  
                  <div>
                    <div className="mb-6">
                      <h3 className="text-sm font-medium text-gray-500 mb-1">Phone</h3>
                      <p className="font-medium">{user?.phone || 'Not provided'}</p>
                    </div>
                    
                    <div className="mb-6">
                      <h3 className="text-sm font-medium text-gray-500 mb-1">Address</h3>
                      {user?.address ? (
                        <p className="font-medium">
                          {user.address}<br />
                          {user.city}, {user.state} {user.zip}<br />
                          {user.country}
                        </p>
                      ) : (
                        <p className="font-medium">Not provided</p>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="mt-6">
                  <Button 
                    className="bg-gold hover:bg-gold-dark text-white font-medium py-2 px-4 rounded transition-colors"
                    onClick={() => setActiveTab("settings")}
                  >
                    Edit Profile
                  </Button>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="orders" className="p-6">
              <h2 className="text-2xl font-medium mb-6">Order History</h2>
              
              {ordersLoading ? (
                <div className="animate-pulse space-y-4">
                  {[...Array(3)].map((_, idx) => (
                    <div key={idx} className="bg-gray-100 h-24 rounded-lg"></div>
                  ))}
                </div>
              ) : orders && orders.length > 0 ? (
                <div className="space-y-6">
                  {orders.map((order) => (
                    <div key={order.id} className="border rounded-lg overflow-hidden">
                      <div className="bg-gray-50 p-4 flex justify-between items-center">
                        <div>
                          <p className="font-medium">Order #{order.id}</p>
                          <p className="text-sm text-gray-500">
                            {new Date(order.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">{formatCurrency(order.total)}</p>
                          <span className={`text-sm px-2 py-1 rounded-full inline-block ${
                            order.status === 'completed' ? 'bg-green-100 text-green-800' :
                            order.status === 'processing' ? 'bg-blue-100 text-blue-800' :
                            'bg-yellow-100 text-yellow-800'
                          }`}>
                            {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                          </span>
                        </div>
                      </div>
                      
                      <div className="p-4 divide-y">
                        {order.items.map((item, idx) => (
                          <div key={idx} className="py-3 flex items-center">
                            <div className="w-16 h-16 rounded-md overflow-hidden mr-4 flex-shrink-0">
                              <img 
                                src={item.image} 
                                alt={item.name} 
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div className="flex-grow">
                              <h3 className="font-medium">{item.name}</h3>
                              <div className="flex justify-between">
                                <p className="text-sm text-gray-500">
                                  Qty: {item.quantity} {item.variant && `(${item.variant})`}
                                </p>
                                <span className="font-medium">{formatCurrency(item.price * item.quantity)}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 border rounded-lg">
                  <i className="ri-shopping-bag-line text-4xl text-gray-300 mb-2"></i>
                  <h3 className="font-medium mb-1">No Orders Yet</h3>
                  <p className="text-gray-500 mb-4">
                    You haven't placed any orders yet.
                  </p>
                  <Button 
                    onClick={() => setLocation('/products')}
                    className="bg-gold hover:bg-gold-dark text-white"
                  >
                    Start Shopping
                  </Button>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="settings" className="p-6">
              <h2 className="text-2xl font-medium mb-6">Account Settings</h2>
              
              <div className="max-w-lg">
                <div className="mb-8">
                  <h3 className="text-lg font-medium mb-4">Security</h3>
                  <Button 
                    variant="outline"
                    className="border-gray-300 text-gray-700 hover:text-gold mb-4"
                  >
                    Change Password
                  </Button>
                  
                  <div className="flex items-center">
                    <input 
                      type="checkbox" 
                      id="2fa" 
                      className="mr-2 h-4 w-4"
                    />
                    <label htmlFor="2fa" className="text-gray-700">
                      Enable two-factor authentication
                    </label>
                  </div>
                </div>
                
                <div className="mb-8">
                  <h3 className="text-lg font-medium mb-4">Preferences</h3>
                  <div className="space-y-3">
                    <div className="flex items-center">
                      <input 
                        type="checkbox" 
                        id="email-offers" 
                        className="mr-2 h-4 w-4"
                        defaultChecked
                      />
                      <label htmlFor="email-offers" className="text-gray-700">
                        Receive exclusive offers by email
                      </label>
                    </div>
                    <div className="flex items-center">
                      <input 
                        type="checkbox" 
                        id="newsletter" 
                        className="mr-2 h-4 w-4"
                        defaultChecked
                      />
                      <label htmlFor="newsletter" className="text-gray-700">
                        Subscribe to newsletter
                      </label>
                    </div>
                    <div className="flex items-center">
                      <input 
                        type="checkbox" 
                        id="sms-updates" 
                        className="mr-2 h-4 w-4"
                      />
                      <label htmlFor="sms-updates" className="text-gray-700">
                        Receive order updates via SMS
                      </label>
                    </div>
                  </div>
                </div>
                
                <div className="mb-8">
                  <h3 className="text-lg font-medium mb-4">Account Management</h3>
                  <Button 
                    onClick={logout}
                    className="bg-black hover:bg-black-light text-white mr-4"
                  >
                    Logout
                  </Button>
                  <Button 
                    variant="outline"
                    className="border-red-300 text-red-600 hover:bg-red-50 hover:text-red-700"
                  >
                    Delete Account
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </>
  );
};

export default AccountPage;
