import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Product } from "@/types";
import { useCart } from "@/hooks/useCart";
import { useWishlist } from "@/hooks/useWishlist";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import ImageGallery from "@/components/ui/ImageGallery";
import QuantitySelector from "@/components/ui/QuantitySelector";
import ProductList from "@/components/product/ProductList";
import Newsletter from "@/components/layout/Newsletter";
import { formatCurrency } from "@/lib/utils";
import { Helmet } from "react-helmet";

const ProductDetailPage = () => {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const productId = parseInt(id);
  const [quantity, setQuantity] = useState(1);
  const [selectedVariant, setSelectedVariant] = useState<string | null>(null);
  
  const { user } = useAuth();
  const { addToCart } = useCart();
  const { addToWishlist, isInWishlist } = useWishlist();
  const { toast } = useToast();

  const { data: product, isLoading } = useQuery<Product>({
    queryKey: [`/api/products/${productId}`],
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-3/4 max-w-md mb-6"></div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="h-96 bg-gray-200 rounded"></div>
            <div>
              <div className="h-8 bg-gray-200 rounded w-1/2 mb-4"></div>
              <div className="h-6 bg-gray-200 rounded w-1/4 mb-6"></div>
              <div className="h-24 bg-gray-200 rounded mb-6"></div>
              <div className="h-10 bg-gray-200 rounded w-1/3 mb-6"></div>
              <div className="flex gap-4 mb-6">
                <div className="h-12 bg-gray-200 rounded w-1/2"></div>
                <div className="h-12 bg-gray-200 rounded w-1/2"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
        <p className="text-gray-600 mb-6">The product you're looking for doesn't exist or has been removed.</p>
        <Button onClick={() => setLocation('/products')}>
          Browse Collections
        </Button>
      </div>
    );
  }

  const handleAddToCart = () => {
    if (!user) {
      toast({
        title: "Please login",
        description: "You need to be logged in to add items to your cart",
        variant: "destructive",
      });
      return;
    }

    addToCart(product.id, quantity, selectedVariant || undefined);
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart`,
    });
  };

  const handleBuyNow = () => {
    if (!user) {
      toast({
        title: "Please login",
        description: "You need to be logged in to purchase items",
        variant: "destructive",
      });
      return;
    }

    addToCart(product.id, quantity, selectedVariant || undefined);
    setLocation('/checkout');
  };

  const handleAddToWishlist = () => {
    if (!user) {
      toast({
        title: "Please login",
        description: "You need to be logged in to add items to your wishlist",
        variant: "destructive",
      });
      return;
    }

    addToWishlist(product.id);
  };

  const handleVariantSelect = (variant: string) => {
    setSelectedVariant(variant);
  };

  const getVariantType = (): string => {
    if (!product.variants) return "";
    return Object.keys(product.variants)[0] || "";
  };

  const getVariantOptions = (): string[] => {
    if (!product.variants) return [];
    const variantType = getVariantType();
    return product.variants[variantType] || [];
  };

  return (
    <>
      <Helmet>
        <title>{product.name} | LUMIÈRE Jewelry</title>
        <meta name="description" content={product.description.substring(0, 160)} />
      </Helmet>
    
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div>
            <ImageGallery images={product.images} alt={product.name} />
          </div>
          
          <div>
            <h1 className="text-3xl md:text-4xl font-serif font-bold mb-4">{product.name}</h1>
            
            <div className="flex items-center mb-4">
              <div className="flex text-gold">
                {[...Array(Math.floor(product.rating))].map((_, i) => (
                  <i key={i} className="ri-star-fill"></i>
                ))}
                
                {product.rating % 1 >= 0.5 && (
                  <i className="ri-star-half-fill"></i>
                )}
                
                {[...Array(5 - Math.ceil(product.rating))].map((_, i) => (
                  <i key={i + Math.ceil(product.rating)} className="ri-star-line"></i>
                ))}
              </div>
              <span className="text-sm text-gray-500 ml-2">{product.reviewCount} reviews</span>
            </div>
            
            <p className="text-2xl font-semibold mb-6">{formatCurrency(product.price)}</p>
            
            <div className="mb-8">
              <p className="text-gray-700 leading-relaxed">{product.description}</p>
            </div>
            
            {product.variants && getVariantOptions().length > 0 && (
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-500 mb-2">{getVariantType()}</h3>
                <div className="flex flex-wrap gap-2">
                  {getVariantOptions().map((variant, idx) => (
                    <button
                      key={idx}
                      className={`w-10 h-10 rounded-full border flex items-center justify-center transition-colors ${
                        selectedVariant === variant
                          ? "border-gold bg-gold-light text-gold font-medium"
                          : "border-gray-300 hover:border-gold"
                      }`}
                      onClick={() => handleVariantSelect(variant)}
                    >
                      {variant}
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            <div className="mb-8">
              <div className="flex items-center mb-4">
                <QuantitySelector
                  quantity={quantity}
                  onIncrease={() => setQuantity(quantity + 1)}
                  onDecrease={() => setQuantity(Math.max(1, quantity - 1))}
                  onQuantityChange={setQuantity}
                  max={product.stock}
                />
                <p className="text-sm text-gray-500 ml-4">
                  {product.stock <= 5
                    ? `Only ${product.stock} items left`
                    : "In stock"}
                </p>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <Button
                  className="w-full bg-gold hover:bg-gold-dark text-white font-medium py-3 px-4 rounded-lg transition-colors"
                  onClick={handleAddToCart}
                >
                  Add to Cart
                </Button>
                <Button
                  className="w-full bg-black hover:bg-black-light text-white font-medium py-3 px-4 rounded-lg transition-colors"
                  onClick={handleBuyNow}
                >
                  Buy Now
                </Button>
              </div>
              
              <Button
                variant="outline"
                className="w-full border-gray-300 text-gray-700 hover:bg-gold-light hover:text-gold hover:border-gold py-3 px-4 rounded-lg transition-colors"
                onClick={handleAddToWishlist}
              >
                <i className={`${isInWishlist(product.id) ? "ri-heart-fill" : "ri-heart-line"} mr-2`}></i>
                {isInWishlist(product.id) ? "In Wishlist" : "Add to Wishlist"}
              </Button>
            </div>
            
            <div className="border-t border-gray-200 pt-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center">
                  <i className="ri-truck-line text-gold text-xl mr-3"></i>
                  <div>
                    <h4 className="font-medium">Free Shipping</h4>
                    <p className="text-sm text-gray-500">On orders over $500</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <i className="ri-shield-check-line text-gold text-xl mr-3"></i>
                  <div>
                    <h4 className="font-medium">Authenticity</h4>
                    <p className="text-sm text-gray-500">Guaranteed genuine</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <i className="ri-refresh-line text-gold text-xl mr-3"></i>
                  <div>
                    <h4 className="font-medium">Easy Returns</h4>
                    <p className="text-sm text-gray-500">30-day returns policy</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <i className="ri-customer-service-line text-gold text-xl mr-3"></i>
                  <div>
                    <h4 className="font-medium">Expert Support</h4>
                    <p className="text-sm text-gray-500">Customer care available</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-16 mb-12">
          <ProductList title="You May Also Like" limit={3} />
        </div>
        
        <Newsletter />
      </div>
    </>
  );
};

export default ProductDetailPage;
