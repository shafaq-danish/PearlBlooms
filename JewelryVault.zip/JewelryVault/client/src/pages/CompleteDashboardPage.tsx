import { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Product, Category } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { formatCurrency } from '@/lib/utils';

// Types for site settings
interface SiteSettings {
  storeName: string;
  currency: string;
  exchangeRate: number;
  logo: string;
  primaryColor: string;
  secondaryColor: string;
  socialLinks: {
    facebook: string;
    instagram: string;
    twitter: string;
    pinterest: string;
  };
  contactInfo: {
    email: string;
    phone: string;
    address: string;
  };
  footerText: string;
}

export default function CompleteDashboardPage() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('site-settings');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  
  // Site settings state
  const [siteSettings, setSiteSettings] = useState<SiteSettings>({
    storeName: 'Pearl Blooms',
    currency: 'PKR',
    exchangeRate: 275, // 1 USD = 275 PKR approx.
    logo: 'https://example.com/logo.png',
    primaryColor: '#D4AF37', // Gold color
    secondaryColor: '#121212', // Dark color
    socialLinks: {
      facebook: 'https://facebook.com/pearlblooms',
      instagram: 'https://instagram.com/pearlblooms',
      twitter: 'https://twitter.com/pearlblooms',
      pinterest: 'https://pinterest.com/pearlblooms'
    },
    contactInfo: {
      email: 'contact@pearlblooms.com',
      phone: '+92 123 456 7890',
      address: 'Shop #123, Main Boulevard, Lahore, Pakistan'
    },
    footerText: '© 2025 Pearl Blooms. All rights reserved.'
  });
  
  // Product form state
  const [productForm, setProductForm] = useState({
    name: '',
    description: '',
    price: 0,
    categoryId: 1,
    images: [''],
    featured: false,
    new: false,
    stock: 0,
    variants: null
  });

  // Fetch products
  const { data: products, isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  // Fetch categories
  const { data: categories, isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  // Update product mutation
  const updateProductMutation = useMutation({
    mutationFn: async (product: Partial<Product>) => {
      if (!editingProduct) return null;
      return apiRequest(`/api/products/${editingProduct.id}`, {
        method: 'PATCH',
        body: JSON.stringify(product)
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      setEditingProduct(null);
      toast({
        title: "Success",
        description: "Product updated successfully",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update product: ${error}`,
        variant: "destructive",
      });
    }
  });

  // Add product mutation
  const addProductMutation = useMutation({
    mutationFn: async (product: Omit<Product, 'id' | 'createdAt'>) => {
      return apiRequest('/api/products', {
        method: 'POST',
        body: JSON.stringify(product)
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      setIsAddingProduct(false);
      resetProductForm();
      toast({
        title: "Success",
        description: "Product added successfully",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add product: ${error}`,
        variant: "destructive",
      });
    }
  });

  // Delete product mutation
  const deleteProductMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/products/${id}`, {
        method: 'DELETE'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      toast({
        title: "Success",
        description: "Product deleted successfully",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete product: ${error}`,
        variant: "destructive",
      });
    }
  });

  // Save site settings (in a real app, this would talk to an API)
  const saveSiteSettings = () => {
    // In a real app, this would be an API call
    // For now we'll just simulate success with a toast
    localStorage.setItem('siteSettings', JSON.stringify(siteSettings));
    
    toast({
      title: "Settings Saved",
      description: "Your site settings have been updated",
      variant: "default",
    });
  };

  // Load site settings from localStorage on initial render
  useEffect(() => {
    const savedSettings = localStorage.getItem('siteSettings');
    if (savedSettings) {
      setSiteSettings(JSON.parse(savedSettings));
    }
  }, []);

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
  };

  const handleUpdateProduct = () => {
    if (!editingProduct) return;
    updateProductMutation.mutate(editingProduct);
  };

  const handleAddProduct = () => {
    // Format the productForm to match expected API format
    const newProduct = {
      ...productForm,
      price: Number(productForm.price),
      categoryId: Number(productForm.categoryId),
      stock: Number(productForm.stock),
    };
    
    addProductMutation.mutate(newProduct as any);
  };

  const handleDeleteProduct = (id: number) => {
    if (confirm('Are you sure you want to delete this product?')) {
      deleteProductMutation.mutate(id);
    }
  };

  const resetProductForm = () => {
    setProductForm({
      name: '',
      description: '',
      price: 0,
      categoryId: 1,
      images: [''],
      featured: false,
      new: false,
      stock: 0,
      variants: null
    });
  };

  // Helper function to handle product form changes
  const handleProductFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setProductForm(prev => ({
        ...prev,
        [name]: checked
      }));
      return;
    }
    
    setProductForm(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Helper function to handle editing product changes
  const handleEditingProductChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    if (!editingProduct) return;
    
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setEditingProduct(prev => ({
        ...prev!,
        [name]: checked
      }));
      return;
    }
    
    setEditingProduct(prev => ({
      ...prev!,
      [name]: value
    }));
  };

  // Handle site settings changes
  const handleSiteSettingsChange = (field: string, value: any) => {
    setSiteSettings(prev => {
      // Handle nested objects (socialLinks, contactInfo)
      if (field.includes('.')) {
        const [parent, child] = field.split('.');
        return {
          ...prev,
          [parent]: {
            ...prev[parent as keyof SiteSettings],
            [child]: value
          }
        };
      }
      
      // Handle top-level fields
      return {
        ...prev,
        [field]: value
      };
    });
  };

  // Helper function to handle image URL changes
  const handleImageChange = (index: number, value: string) => {
    setProductForm(prev => {
      const newImages = [...prev.images];
      newImages[index] = value;
      return {
        ...prev,
        images: newImages
      };
    });
  };

  // Helper function to add a new image input field
  const addImageField = () => {
    setProductForm(prev => ({
      ...prev,
      images: [...prev.images, '']
    }));
  };

  // Helper function to remove an image input field
  const removeImageField = (index: number) => {
    setProductForm(prev => {
      const newImages = prev.images.filter((_, i) => i !== index);
      return {
        ...prev,
        images: newImages.length ? newImages : ['']
      };
    });
  };

  // Helper function to handle editing product image changes
  const handleEditingProductImageChange = (index: number, value: string) => {
    if (!editingProduct) return;
    
    setEditingProduct(prev => {
      const newImages = [...prev!.images];
      newImages[index] = value;
      return {
        ...prev!,
        images: newImages
      };
    });
  };

  // Helper function to add a new image input field for editing product
  const addEditingProductImageField = () => {
    if (!editingProduct) return;
    
    setEditingProduct(prev => ({
      ...prev!,
      images: [...prev!.images, '']
    }));
  };

  // Helper function to remove an image input field for editing product
  const removeEditingProductImageField = (index: number) => {
    if (!editingProduct) return;
    
    setEditingProduct(prev => {
      const newImages = prev!.images.filter((_, i) => i !== index);
      return {
        ...prev!,
        images: newImages.length ? newImages : ['']
      };
    });
  };

  // Format price in PKR
  const formatPKR = (amount: number) => {
    return `₨ ${(amount * siteSettings.exchangeRate).toLocaleString('en-PK')}`;
  };

  if (productsLoading || categoriesLoading) {
    return <div className="container py-8">Loading dashboard...</div>;
  }

  return (
    <div className="container py-8">
      <Helmet>
        <title>Complete Admin Dashboard | {siteSettings.storeName}</title>
        <meta name="description" content="Manage your store's products, appearance, and settings" />
      </Helmet>

      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">{siteSettings.storeName} Admin Dashboard</h1>
        <p className="text-muted-foreground">Manage your entire store from one place</p>
      </div>

      <Tabs defaultValue="site-settings" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-8">
          <TabsTrigger value="site-settings">Site Settings</TabsTrigger>
          <TabsTrigger value="content-management">Content Management</TabsTrigger>
          <TabsTrigger value="products">Products</TabsTrigger>
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="social-media">Social Media</TabsTrigger>
          <TabsTrigger value="design">Theme & Design</TabsTrigger>
          <TabsTrigger value="features">Site Features</TabsTrigger>
        </TabsList>

        {/* CONTENT MANAGEMENT TAB */}
        <TabsContent value="content-management" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Website Content Management</CardTitle>
              <CardDescription>
                Edit all text content throughout your website
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Homepage Sections</h3>
                <Separator className="my-2" />
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="hero-title">Hero Section Title</Label>
                    <Input 
                      id="hero-title" 
                      placeholder="Timeless Elegance, Modern Luxury" 
                      defaultValue="Timeless Elegance, Modern Luxury"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="hero-subtitle">Hero Section Subtitle</Label>
                    <Input 
                      id="hero-subtitle" 
                      placeholder="Discover our handcrafted jewelry collection" 
                      defaultValue="Discover our handcrafted jewelry collection"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="hero-description">Hero Description</Label>
                    <Textarea 
                      id="hero-description" 
                      placeholder="Each piece tells a story of craftsmanship..." 
                      defaultValue="Each piece tells a story of craftsmanship and timeless beauty, designed to be cherished for generations."
                      rows={3}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="hero-button-text">Hero Button Text</Label>
                    <Input 
                      id="hero-button-text" 
                      placeholder="Shop Collection" 
                      defaultValue="Shop Collection"
                    />
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Featured Collections</h3>
                <Separator className="my-2" />
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="featured-title">Section Title</Label>
                    <Input 
                      id="featured-title" 
                      placeholder="Our Featured Collections" 
                      defaultValue="Our Featured Collections"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="featured-description">Section Description</Label>
                    <Textarea 
                      id="featured-description" 
                      placeholder="Explore our most coveted pieces..." 
                      defaultValue="Explore our most coveted pieces, each one a testament to exceptional craftsmanship and timeless beauty."
                      rows={3}
                    />
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <h3 className="text-lg font-medium">About Section</h3>
                <Separator className="my-2" />
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="about-title">Section Title</Label>
                    <Input 
                      id="about-title" 
                      placeholder="Our Story" 
                      defaultValue="Our Story"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="about-text">About Text</Label>
                    <Textarea 
                      id="about-text" 
                      placeholder="Founded in 2020, Pearl Blooms began with a passion..." 
                      defaultValue="Founded in 2020, Pearl Blooms began with a passion for creating exquisite jewelry that captures life's most precious moments. Our artisans combine traditional techniques with modern design, ensuring each piece is as unique as the story it represents."
                      rows={5}
                    />
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Newsletter Section</h3>
                <Separator className="my-2" />
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="newsletter-title">Section Title</Label>
                    <Input 
                      id="newsletter-title" 
                      placeholder="Join Our Newsletter" 
                      defaultValue="Join Our Newsletter"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="newsletter-description">Section Description</Label>
                    <Textarea 
                      id="newsletter-description" 
                      placeholder="Subscribe to receive updates..." 
                      defaultValue="Subscribe to receive updates on new collections, exclusive offers, and jewelry care tips."
                      rows={3}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="newsletter-button">Button Text</Label>
                    <Input 
                      id="newsletter-button" 
                      placeholder="Subscribe" 
                      defaultValue="Subscribe"
                    />
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Footer Content</h3>
                <Separator className="my-2" />
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="footer-about">About Us Text</Label>
                    <Textarea 
                      id="footer-about" 
                      placeholder="Pearl Blooms creates timeless jewelry..." 
                      defaultValue="Pearl Blooms creates timeless jewelry that celebrates life's precious moments. Each piece is crafted with care and attention to detail."
                      rows={3}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="footer-copyright">Copyright Text</Label>
                    <Input 
                      id="footer-copyright" 
                      placeholder="© 2025 Pearl Blooms. All rights reserved." 
                      defaultValue="© 2025 Pearl Blooms. All rights reserved."
                    />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button>Save Content Changes</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* SITE SETTINGS TAB */}
        <TabsContent value="site-settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Store Settings</CardTitle>
              <CardDescription>
                Update your store name, currency, and other basic settings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="storeName">Store Name</Label>
                  <Input 
                    id="storeName" 
                    value={siteSettings.storeName} 
                    onChange={(e) => handleSiteSettingsChange('storeName', e.target.value)}
                    placeholder="Pearl Blooms"
                  />
                  <p className="text-sm text-muted-foreground">This appears in the header, title tags, and throughout the site</p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="currency">Currency</Label>
                  <Select 
                    value={siteSettings.currency}
                    onValueChange={(value) => handleSiteSettingsChange('currency', value)}
                  >
                    <SelectTrigger id="currency">
                      <SelectValue placeholder="Select currency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="USD">US Dollar ($)</SelectItem>
                      <SelectItem value="PKR">Pakistani Rupee (₨)</SelectItem>
                      <SelectItem value="EUR">Euro (€)</SelectItem>
                      <SelectItem value="GBP">British Pound (£)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="exchangeRate">Exchange Rate (1 USD to PKR)</Label>
                  <Input 
                    id="exchangeRate" 
                    type="number"
                    value={siteSettings.exchangeRate} 
                    onChange={(e) => handleSiteSettingsChange('exchangeRate', Number(e.target.value))}
                    placeholder="275"
                  />
                  <p className="text-sm text-muted-foreground">Used to convert product prices from USD to PKR</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="primaryColor">Primary Color</Label>
                  <div className="flex gap-2">
                    <Input 
                      id="primaryColor" 
                      type="color"
                      value={siteSettings.primaryColor}
                      onChange={(e) => handleSiteSettingsChange('primaryColor', e.target.value)}
                      className="w-12 h-10 p-1"
                    />
                    <Input 
                      value={siteSettings.primaryColor}
                      onChange={(e) => handleSiteSettingsChange('primaryColor', e.target.value)}
                      placeholder="#D4AF37"
                    />
                  </div>
                </div>
              </div>

              <Separator className="my-4" />
              
              <div className="space-y-2">
                <Label htmlFor="contactEmail">Contact Email</Label>
                <Input 
                  id="contactEmail" 
                  value={siteSettings.contactInfo.email} 
                  onChange={(e) => handleSiteSettingsChange('contactInfo.email', e.target.value)}
                  placeholder="contact@pearlblooms.com"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="contactPhone">Contact Phone</Label>
                <Input 
                  id="contactPhone" 
                  value={siteSettings.contactInfo.phone} 
                  onChange={(e) => handleSiteSettingsChange('contactInfo.phone', e.target.value)}
                  placeholder="+92 123 456 7890"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="contactAddress">Store Address</Label>
                <Textarea 
                  id="contactAddress" 
                  value={siteSettings.contactInfo.address} 
                  onChange={(e) => handleSiteSettingsChange('contactInfo.address', e.target.value)}
                  placeholder="Shop #123, Main Boulevard, Lahore, Pakistan"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="footerText">Footer Text</Label>
                <Input 
                  id="footerText" 
                  value={siteSettings.footerText} 
                  onChange={(e) => handleSiteSettingsChange('footerText', e.target.value)}
                  placeholder="© 2025 Pearl Blooms. All rights reserved."
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={saveSiteSettings}>Save Store Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* PRODUCTS TAB */}
        <TabsContent value="products" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-semibold">Product Management</h2>
            <Dialog open={isAddingProduct} onOpenChange={setIsAddingProduct}>
              <DialogTrigger asChild>
                <Button>Add New Product</Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Add New Product</DialogTitle>
                  <DialogDescription>
                    Create a new product for your store. Fill in all the details below.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right font-medium">Name</label>
                    <Input
                      name="name"
                      value={productForm.name}
                      onChange={handleProductFormChange}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-start gap-4">
                    <label className="text-right font-medium">Description</label>
                    <Textarea
                      name="description"
                      value={productForm.description}
                      onChange={handleProductFormChange}
                      className="col-span-3 h-24"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right font-medium">Price (USD)</label>
                    <Input
                      type="number"
                      name="price"
                      value={productForm.price}
                      onChange={handleProductFormChange}
                      className="col-span-3"
                    />
                    <label className="text-right font-medium">Price (PKR)</label>
                    <div className="col-span-3 text-muted-foreground">
                      {formatPKR(productForm.price)}
                    </div>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right font-medium">Category</label>
                    <Select
                      name="categoryId"
                      value={String(productForm.categoryId)}
                      onValueChange={(value) => setProductForm(prev => ({ ...prev, categoryId: Number(value) }))}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories?.map(category => (
                          <SelectItem key={category.id} value={String(category.id)}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right font-medium">Stock</label>
                    <Input
                      type="number"
                      name="stock"
                      value={productForm.stock}
                      onChange={handleProductFormChange}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right font-medium">Featured</label>
                    <div className="col-span-3 flex items-center">
                      <Switch
                        checked={productForm.featured}
                        onCheckedChange={(checked) => 
                          setProductForm(prev => ({ ...prev, featured: checked }))
                        }
                        id="featured-product"
                      />
                      <label htmlFor="featured-product" className="ml-2">
                        Display as featured product
                      </label>
                    </div>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right font-medium">New</label>
                    <div className="col-span-3 flex items-center">
                      <Switch
                        checked={productForm.new}
                        onCheckedChange={(checked) => 
                          setProductForm(prev => ({ ...prev, new: checked }))
                        }
                        id="new-product"
                      />
                      <label htmlFor="new-product" className="ml-2">
                        Mark as new product
                      </label>
                    </div>
                  </div>
                  <Separator className="my-2" />
                  <h3 className="font-semibold">Product Images</h3>
                  <div className="space-y-2">
                    {productForm.images.map((image, index) => (
                      <div key={index} className="flex gap-2">
                        <Input
                          value={image}
                          onChange={(e) => handleImageChange(index, e.target.value)}
                          placeholder="Image URL"
                          className="flex-1"
                        />
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => removeImageField(index)}
                          disabled={productForm.images.length === 1}
                        >
                          ✕
                        </Button>
                      </div>
                    ))}
                    <Button variant="outline" onClick={addImageField} className="w-full">
                      Add Image URL
                    </Button>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAddingProduct(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddProduct} disabled={addProductMutation.isPending}>
                    {addProductMutation.isPending ? 'Adding...' : 'Add Product'}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Price (USD)</TableHead>
                  <TableHead>Price (PKR)</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Stock</TableHead>
                  <TableHead>Featured</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {products?.map((product) => (
                  <TableRow key={product.id}>
                    <TableCell>{product.id}</TableCell>
                    <TableCell className="font-medium">{product.name}</TableCell>
                    <TableCell>{formatCurrency(product.price)}</TableCell>
                    <TableCell>{formatPKR(product.price)}</TableCell>
                    <TableCell>
                      {categories?.find(c => c.id === product.categoryId)?.name || 'Unknown'}
                    </TableCell>
                    <TableCell>{product.stock}</TableCell>
                    <TableCell>{product.featured ? 'Yes' : 'No'}</TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" onClick={() => handleEditProduct(product)}>
                          Edit
                        </Button>
                        <Button variant="destructive" size="sm" onClick={() => handleDeleteProduct(product.id)}>
                          Delete
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* Edit Product Dialog */}
          {editingProduct && (
            <Dialog open={!!editingProduct} onOpenChange={(open) => !open && setEditingProduct(null)}>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Edit Product</DialogTitle>
                  <DialogDescription>
                    Update product details. Changes will be reflected immediately on your store.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right font-medium">Name</label>
                    <Input
                      name="name"
                      value={editingProduct.name}
                      onChange={handleEditingProductChange}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-start gap-4">
                    <label className="text-right font-medium">Description</label>
                    <Textarea
                      name="description"
                      value={editingProduct.description}
                      onChange={handleEditingProductChange}
                      className="col-span-3 h-24"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right font-medium">Price (USD)</label>
                    <Input
                      type="number"
                      name="price"
                      value={editingProduct.price}
                      onChange={handleEditingProductChange}
                      className="col-span-3"
                    />
                    <label className="text-right font-medium">Price (PKR)</label>
                    <div className="col-span-3 text-muted-foreground">
                      {formatPKR(editingProduct.price)}
                    </div>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right font-medium">Category</label>
                    <Select
                      value={String(editingProduct.categoryId)}
                      onValueChange={(value) => setEditingProduct({...editingProduct, categoryId: Number(value)})}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories?.map(category => (
                          <SelectItem key={category.id} value={String(category.id)}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right font-medium">Stock</label>
                    <Input
                      type="number"
                      name="stock"
                      value={editingProduct.stock}
                      onChange={handleEditingProductChange}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right font-medium">Featured</label>
                    <div className="col-span-3 flex items-center">
                      <Switch
                        checked={editingProduct.featured}
                        onCheckedChange={(checked) => 
                          setEditingProduct({...editingProduct, featured: checked})
                        }
                        id="edit-featured-product"
                      />
                      <label htmlFor="edit-featured-product" className="ml-2">
                        Display as featured product
                      </label>
                    </div>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right font-medium">New</label>
                    <div className="col-span-3 flex items-center">
                      <Switch
                        checked={editingProduct.new}
                        onCheckedChange={(checked) => 
                          setEditingProduct({...editingProduct, new: checked})
                        }
                        id="edit-new-product"
                      />
                      <label htmlFor="edit-new-product" className="ml-2">
                        Mark as new product
                      </label>
                    </div>
                  </div>
                  <Separator className="my-2" />
                  <h3 className="font-semibold">Product Images</h3>
                  <div className="space-y-2">
                    {editingProduct.images.map((image, index) => (
                      <div key={index} className="flex gap-2">
                        <Input
                          value={image}
                          onChange={(e) => handleEditingProductImageChange(index, e.target.value)}
                          placeholder="Image URL"
                          className="flex-1"
                        />
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => removeEditingProductImageField(index)}
                          disabled={editingProduct.images.length === 1}
                        >
                          ✕
                        </Button>
                      </div>
                    ))}
                    <Button variant="outline" onClick={addEditingProductImageField} className="w-full">
                      Add Image URL
                    </Button>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setEditingProduct(null)}>
                    Cancel
                  </Button>
                  <Button onClick={handleUpdateProduct} disabled={updateProductMutation.isPending}>
                    {updateProductMutation.isPending ? 'Saving...' : 'Save Changes'}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
        </TabsContent>

        {/* CATEGORIES TAB */}
        <TabsContent value="categories" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Category Management</CardTitle>
              <CardDescription>
                View and manage product categories
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Slug</TableHead>
                        <TableHead>Image</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {categories?.map((category) => (
                        <TableRow key={category.id}>
                          <TableCell>{category.id}</TableCell>
                          <TableCell className="font-medium">{category.name}</TableCell>
                          <TableCell>{category.slug}</TableCell>
                          <TableCell>
                            <img 
                              src={category.image} 
                              alt={category.name} 
                              className="w-16 h-12 object-cover rounded"
                              onError={(e) => {
                                const target = e.target as HTMLImageElement;
                                target.src = 'https://placehold.co/300x200?text=No+Image';
                              }}
                            />
                          </TableCell>
                          <TableCell>
                            <Button variant="outline" size="sm">
                              Edit
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                <p className="text-center text-muted-foreground">
                  Category editing features coming soon
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* SOCIAL MEDIA TAB */}
        <TabsContent value="social-media" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Social Media Links</CardTitle>
              <CardDescription>
                Update your store's social media profiles
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="facebook">Facebook</Label>
                <Input 
                  id="facebook" 
                  value={siteSettings.socialLinks.facebook} 
                  onChange={(e) => handleSiteSettingsChange('socialLinks.facebook', e.target.value)}
                  placeholder="https://facebook.com/pearlblooms"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="instagram">Instagram</Label>
                <Input 
                  id="instagram" 
                  value={siteSettings.socialLinks.instagram} 
                  onChange={(e) => handleSiteSettingsChange('socialLinks.instagram', e.target.value)}
                  placeholder="https://instagram.com/pearlblooms"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="twitter">Twitter</Label>
                <Input 
                  id="twitter" 
                  value={siteSettings.socialLinks.twitter} 
                  onChange={(e) => handleSiteSettingsChange('socialLinks.twitter', e.target.value)}
                  placeholder="https://twitter.com/pearlblooms"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="pinterest">Pinterest</Label>
                <Input 
                  id="pinterest" 
                  value={siteSettings.socialLinks.pinterest} 
                  onChange={(e) => handleSiteSettingsChange('socialLinks.pinterest', e.target.value)}
                  placeholder="https://pinterest.com/pearlblooms"
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={saveSiteSettings}>Save Social Media Links</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* THEME & DESIGN TAB */}
        <TabsContent value="design" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Theme & Design Customization</CardTitle>
              <CardDescription>
                Customize the look and feel of your entire website
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Brand Colors</h3>
                <Separator className="my-2" />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="primaryColor">Primary Color (Gold)</Label>
                    <div className="flex gap-2">
                      <Input 
                        id="primaryColor" 
                        type="color"
                        value={siteSettings.primaryColor}
                        onChange={(e) => handleSiteSettingsChange('primaryColor', e.target.value)}
                        className="w-12 h-10 p-1"
                      />
                      <Input 
                        value={siteSettings.primaryColor}
                        onChange={(e) => handleSiteSettingsChange('primaryColor', e.target.value)}
                        placeholder="#D4AF37"
                      />
                    </div>
                    <p className="text-sm text-muted-foreground">Used for buttons, accents and highlights</p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="secondaryColor">Secondary Color (Dark)</Label>
                    <div className="flex gap-2">
                      <Input 
                        id="secondaryColor" 
                        type="color"
                        value={siteSettings.secondaryColor}
                        onChange={(e) => handleSiteSettingsChange('secondaryColor', e.target.value)}
                        className="w-12 h-10 p-1"
                      />
                      <Input 
                        value={siteSettings.secondaryColor}
                        onChange={(e) => handleSiteSettingsChange('secondaryColor', e.target.value)}
                        placeholder="#121212"
                      />
                    </div>
                    <p className="text-sm text-muted-foreground">Used for text and backgrounds</p>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Typography</h3>
                <Separator className="my-2" />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="headingFont">Heading Font</Label>
                    <Select defaultValue="Playfair Display">
                      <SelectTrigger id="headingFont">
                        <SelectValue placeholder="Select font" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Playfair Display">Playfair Display</SelectItem>
                        <SelectItem value="Cormorant Garamond">Cormorant Garamond</SelectItem>
                        <SelectItem value="Libre Baskerville">Libre Baskerville</SelectItem>
                        <SelectItem value="Cinzel">Cinzel</SelectItem>
                        <SelectItem value="Lora">Lora</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-sm text-muted-foreground">Used for titles and headings</p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="bodyFont">Body Font</Label>
                    <Select defaultValue="Montserrat">
                      <SelectTrigger id="bodyFont">
                        <SelectValue placeholder="Select font" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Montserrat">Montserrat</SelectItem>
                        <SelectItem value="Raleway">Raleway</SelectItem>
                        <SelectItem value="Open Sans">Open Sans</SelectItem>
                        <SelectItem value="Roboto">Roboto</SelectItem>
                        <SelectItem value="Lato">Lato</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-sm text-muted-foreground">Used for main text content</p>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Header Style</h3>
                <Separator className="my-2" />
                
                <div className="grid grid-cols-1 gap-4">
                  <div className="flex items-center space-x-2">
                    <Switch id="transparentHeader" defaultChecked />
                    <Label htmlFor="transparentHeader">Transparent header on homepage</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch id="stickyHeader" defaultChecked />
                    <Label htmlFor="stickyHeader">Sticky header (stays visible when scrolling)</Label>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="logoSize">Logo Size</Label>
                    <Select defaultValue="medium">
                      <SelectTrigger id="logoSize">
                        <SelectValue placeholder="Select size" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="small">Small</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="large">Large</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Button Style</h3>
                <Separator className="my-2" />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="buttonStyle">Button Shape</Label>
                    <Select defaultValue="rounded">
                      <SelectTrigger id="buttonStyle">
                        <SelectValue placeholder="Select style" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="rounded">Rounded</SelectItem>
                        <SelectItem value="pill">Pill Shaped</SelectItem>
                        <SelectItem value="square">Square</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="buttonEffect">Button Hover Effect</Label>
                    <Select defaultValue="darken">
                      <SelectTrigger id="buttonEffect">
                        <SelectValue placeholder="Select effect" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="darken">Darken</SelectItem>
                        <SelectItem value="glow">Subtle Glow</SelectItem>
                        <SelectItem value="scale">Scale Up</SelectItem>
                        <SelectItem value="border">Border Animation</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Product Cards</h3>
                <Separator className="my-2" />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="cardStyle">Card Style</Label>
                    <Select defaultValue="shadow">
                      <SelectTrigger id="cardStyle">
                        <SelectValue placeholder="Select style" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="shadow">Subtle Shadow</SelectItem>
                        <SelectItem value="border">Bordered</SelectItem>
                        <SelectItem value="minimal">Minimal</SelectItem>
                        <SelectItem value="elevated">Elevated</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="cardHoverEffect">Card Hover Effect</Label>
                    <Select defaultValue="zoom">
                      <SelectTrigger id="cardHoverEffect">
                        <SelectValue placeholder="Select effect" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="zoom">Image Zoom</SelectItem>
                        <SelectItem value="lift">Lift Up</SelectItem>
                        <SelectItem value="glow">Subtle Glow</SelectItem>
                        <SelectItem value="none">None</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Page Transitions</h3>
                <Separator className="my-2" />
                
                <div className="space-y-2">
                  <Label htmlFor="pageTransition">Page Transition Effect</Label>
                  <Select defaultValue="fade">
                    <SelectTrigger id="pageTransition">
                      <SelectValue placeholder="Select transition" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fade">Fade</SelectItem>
                      <SelectItem value="slide">Slide Up</SelectItem>
                      <SelectItem value="none">None</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={saveSiteSettings}>Save Design Changes</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* SITE FEATURES TAB */}
        <TabsContent value="features" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Site Features & Components</CardTitle>
              <CardDescription>
                Enable or disable features throughout your website
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Homepage Components</h3>
                <Separator className="my-2" />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between border p-4 rounded-lg">
                    <div>
                      <h4 className="font-medium">Hero Section</h4>
                      <p className="text-sm text-muted-foreground">Main banner at the top of the homepage</p>
                    </div>
                    <Switch id="enableHero" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between border p-4 rounded-lg">
                    <div>
                      <h4 className="font-medium">Featured Collections</h4>
                      <p className="text-sm text-muted-foreground">Showcase your best product collections</p>
                    </div>
                    <Switch id="enableFeatured" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between border p-4 rounded-lg">
                    <div>
                      <h4 className="font-medium">New Arrivals</h4>
                      <p className="text-sm text-muted-foreground">Display your newest products</p>
                    </div>
                    <Switch id="enableNewArrivals" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between border p-4 rounded-lg">
                    <div>
                      <h4 className="font-medium">Testimonials</h4>
                      <p className="text-sm text-muted-foreground">Customer reviews and feedback</p>
                    </div>
                    <Switch id="enableTestimonials" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between border p-4 rounded-lg">
                    <div>
                      <h4 className="font-medium">Instagram Feed</h4>
                      <p className="text-sm text-muted-foreground">Show your Instagram posts</p>
                    </div>
                    <Switch id="enableInstagram" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between border p-4 rounded-lg">
                    <div>
                      <h4 className="font-medium">Newsletter Signup</h4>
                      <p className="text-sm text-muted-foreground">Email subscription form</p>
                    </div>
                    <Switch id="enableNewsletter" defaultChecked />
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Product Page Features</h3>
                <Separator className="my-2" />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between border p-4 rounded-lg">
                    <div>
                      <h4 className="font-medium">Product Image Gallery</h4>
                      <p className="text-sm text-muted-foreground">Multiple product images with zoom</p>
                    </div>
                    <Switch id="enableGallery" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between border p-4 rounded-lg">
                    <div>
                      <h4 className="font-medium">Product Reviews</h4>
                      <p className="text-sm text-muted-foreground">Customer reviews and ratings</p>
                    </div>
                    <Switch id="enableReviews" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between border p-4 rounded-lg">
                    <div>
                      <h4 className="font-medium">Related Products</h4>
                      <p className="text-sm text-muted-foreground">Show similar or complementary items</p>
                    </div>
                    <Switch id="enableRelated" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between border p-4 rounded-lg">
                    <div>
                      <h4 className="font-medium">Size Guide</h4>
                      <p className="text-sm text-muted-foreground">Help customers find their size</p>
                    </div>
                    <Switch id="enableSizeGuide" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between border p-4 rounded-lg">
                    <div>
                      <h4 className="font-medium">Wishlist Button</h4>
                      <p className="text-sm text-muted-foreground">Save products for later</p>
                    </div>
                    <Switch id="enableWishlist" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between border p-4 rounded-lg">
                    <div>
                      <h4 className="font-medium">Share Buttons</h4>
                      <p className="text-sm text-muted-foreground">Social media sharing options</p>
                    </div>
                    <Switch id="enableShare" defaultChecked />
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Checkout Features</h3>
                <Separator className="my-2" />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between border p-4 rounded-lg">
                    <div>
                      <h4 className="font-medium">Guest Checkout</h4>
                      <p className="text-sm text-muted-foreground">Purchase without creating an account</p>
                    </div>
                    <Switch id="enableGuestCheckout" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between border p-4 rounded-lg">
                    <div>
                      <h4 className="font-medium">Promo Code Field</h4>
                      <p className="text-sm text-muted-foreground">Apply discount codes at checkout</p>
                    </div>
                    <Switch id="enablePromoCodes" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between border p-4 rounded-lg">
                    <div>
                      <h4 className="font-medium">Order Tracking</h4>
                      <p className="text-sm text-muted-foreground">Track shipment status</p>
                    </div>
                    <Switch id="enableOrderTracking" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between border p-4 rounded-lg">
                    <div>
                      <h4 className="font-medium">Save Payment Info</h4>
                      <p className="text-sm text-muted-foreground">Save payment details for future purchases</p>
                    </div>
                    <Switch id="enableSavedPayments" defaultChecked />
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Global Features</h3>
                <Separator className="my-2" />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between border p-4 rounded-lg">
                    <div>
                      <h4 className="font-medium">Search Functionality</h4>
                      <p className="text-sm text-muted-foreground">Site-wide product search</p>
                    </div>
                    <Switch id="enableSearch" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between border p-4 rounded-lg">
                    <div>
                      <h4 className="font-medium">Live Chat Support</h4>
                      <p className="text-sm text-muted-foreground">Customer service chat widget</p>
                    </div>
                    <Switch id="enableLiveChat" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between border p-4 rounded-lg">
                    <div>
                      <h4 className="font-medium">Cookie Consent Banner</h4>
                      <p className="text-sm text-muted-foreground">GDPR compliance notification</p>
                    </div>
                    <Switch id="enableCookieConsent" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between border p-4 rounded-lg">
                    <div>
                      <h4 className="font-medium">Dark Mode</h4>
                      <p className="text-sm text-muted-foreground">Allow users to switch between light/dark themes</p>
                    </div>
                    <Switch id="enableDarkMode" defaultChecked />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button>Save Feature Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}