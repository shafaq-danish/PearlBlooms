import { useWishlist } from "@/hooks/useWishlist";
import { useAuth } from "@/context/AuthContext";
import { useCart } from "@/hooks/useCart";
import { formatCurrency } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import Newsletter from "@/components/layout/Newsletter";
import { Helmet } from "react-helmet";

const WishlistPage = () => {
  const [, setLocation] = useLocation();
  const { wishlistItems, removeFromWishlist, isLoading } = useWishlist();
  const { addToCart } = useCart();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const handleAddToCart = (productId: number) => {
    addToCart(productId);
    toast({
      title: "Added to cart",
      description: "Item has been added to your cart",
    });
  };
  
  if (!user) {
    return (
      <>
        <Helmet>
          <title>Wishlist | LUMIÈRE Jewelry</title>
          <meta name="description" content="View and manage your wishlist. Save your favorite luxury jewelry pieces for later." />
        </Helmet>
      
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-2xl mx-auto text-center">
            <h1 className="text-3xl md:text-4xl font-serif font-bold mb-4">Wishlist</h1>
            <p className="text-gray-600 mb-8">Please log in to view your wishlist</p>
            <Button onClick={() => setLocation('/login?redirect=wishlist')}>
              Login to View Wishlist
            </Button>
          </div>
        </div>
      </>
    );
  }
  
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12">
        <h1 className="text-3xl md:text-4xl font-serif font-bold mb-8">My Wishlist</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(3)].map((_, index) => (
            <div key={index} className="bg-white rounded-lg overflow-hidden shadow-sm animate-pulse">
              <div className="h-64 bg-gray-200"></div>
              <div className="p-4">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2 mb-4"></div>
                <div className="h-8 bg-gray-200 rounded w-full"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
  
  if (wishlistItems.length === 0) {
    return (
      <>
        <Helmet>
          <title>Wishlist | LUMIÈRE Jewelry</title>
          <meta name="description" content="View and manage your wishlist. Save your favorite luxury jewelry pieces for later." />
        </Helmet>
      
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-2xl mx-auto text-center">
            <h1 className="text-3xl md:text-4xl font-serif font-bold mb-4">Your Wishlist is Empty</h1>
            <p className="text-gray-600 mb-8">You haven't added any items to your wishlist yet.</p>
            <Button onClick={() => setLocation('/products')}>
              Explore Collections
            </Button>
          </div>
        </div>
      </>
    );
  }
  
  return (
    <>
      <Helmet>
        <title>Wishlist | LUMIÈRE Jewelry</title>
        <meta name="description" content="View and manage your wishlist. Save your favorite luxury jewelry pieces for later." />
      </Helmet>
    
      <div className="container mx-auto px-4 py-12">
        <h1 className="text-3xl md:text-4xl font-serif font-bold mb-8">My Wishlist</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {wishlistItems.map((item) => (
            <div key={item.id} className="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
              <div className="relative">
                <img 
                  src={item.product?.images[0]} 
                  alt={item.product?.name} 
                  className="w-full h-64 object-cover"
                />
                <button 
                  className="absolute top-4 right-4 bg-white hover:bg-red-50 text-red-500 w-8 h-8 rounded-full flex items-center justify-center transition-colors" 
                  onClick={() => removeFromWishlist(item.id)}
                  aria-label="Remove from wishlist"
                >
                  <i className="ri-close-line"></i>
                </button>
              </div>
              <div className="p-4">
                <h3 className="font-medium mb-2">{item.product?.name}</h3>
                <p className="text-gray-600 mb-4">{formatCurrency(item.product?.price || 0)}</p>
                <Button 
                  className="w-full bg-gold hover:bg-gold-dark text-white font-medium py-2"
                  onClick={() => handleAddToCart(item.productId)}
                >
                  Add to Cart
                </Button>
              </div>
            </div>
          ))}
        </div>
        
        <Newsletter />
      </div>
    </>
  );
};

export default WishlistPage;
