import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useCart } from "@/hooks/useCart";
import { formatCurrency } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import QuantitySelector from "@/components/ui/QuantitySelector";
import Newsletter from "@/components/layout/Newsletter";
import { Helmet } from "react-helmet";

const CartPage = () => {
  const { cartItems, removeFromCart, updateCartItemQuantity, getCartTotal, clearCart } = useCart();
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [isProcessing, setIsProcessing] = useState(false);
  
  const handleCheckout = () => {
    if (!user) {
      setLocation('/login?redirect=checkout');
      return;
    }
    
    setLocation('/checkout');
  };
  
  if (!user) {
    return (
      <>
        <Helmet>
          <title>Shopping Cart | LUMIÈRE Jewelry</title>
          <meta name="description" content="View and manage your shopping cart. Securely checkout and complete your purchase of luxury jewelry items." />
        </Helmet>
      
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-2xl mx-auto text-center">
            <h1 className="text-3xl md:text-4xl font-serif font-bold mb-4">Shopping Cart</h1>
            <p className="text-gray-600 mb-8">Please log in to view your cart</p>
            <Button onClick={() => setLocation('/login?redirect=cart')}>
              Login to View Cart
            </Button>
          </div>
        </div>
      </>
    );
  }
  
  const subtotal = getCartTotal();
  const shipping = subtotal >= 500 ? 0 : 25;
  const total = subtotal + shipping;
  
  if (cartItems.length === 0) {
    return (
      <>
        <Helmet>
          <title>Shopping Cart | LUMIÈRE Jewelry</title>
          <meta name="description" content="View and manage your shopping cart. Securely checkout and complete your purchase of luxury jewelry items." />
        </Helmet>
      
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-2xl mx-auto text-center">
            <h1 className="text-3xl md:text-4xl font-serif font-bold mb-4">Your Cart is Empty</h1>
            <p className="text-gray-600 mb-8">Looks like you haven't added any jewelry to your cart yet.</p>
            <Button onClick={() => setLocation('/products')}>
              Continue Shopping
            </Button>
          </div>
        </div>
      </>
    );
  }
  
  return (
    <>
      <Helmet>
        <title>Shopping Cart | LUMIÈRE Jewelry</title>
        <meta name="description" content="View and manage your shopping cart. Securely checkout and complete your purchase of luxury jewelry items." />
      </Helmet>
    
      <div className="container mx-auto px-4 py-12">
        <h1 className="text-3xl md:text-4xl font-serif font-bold mb-8">Shopping Cart</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="p-6 border-b">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-medium">Cart Items ({cartItems.length})</h2>
                  <button 
                    onClick={clearCart}
                    className="text-sm text-gray-500 hover:text-gold"
                  >
                    Clear Cart
                  </button>
                </div>
              </div>
              
              <div className="divide-y">
                {cartItems.map((item) => (
                  <div key={item.id} className="p-6 flex flex-col sm:flex-row">
                    <div className="sm:w-24 sm:h-24 w-full h-40 rounded-md overflow-hidden mb-4 sm:mb-0 sm:mr-4 flex-shrink-0">
                      <img 
                        src={item.product?.images[0]} 
                        alt={item.product?.name} 
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-grow">
                      <div className="flex flex-col sm:flex-row sm:justify-between">
                        <div>
                          <h3 className="font-medium mb-1">{item.product?.name}</h3>
                          {item.variant && (
                            <p className="text-sm text-gray-500 mb-2">{item.variant}</p>
                          )}
                        </div>
                        <span className="font-semibold order-3 sm:order-2 mt-2 sm:mt-0">
                          {formatCurrency((item.product?.price || 0) * item.quantity)}
                        </span>
                      </div>
                      <div className="flex justify-between items-center mt-4">
                        <div className="flex items-center">
                          <QuantitySelector
                            quantity={item.quantity}
                            onIncrease={() => updateCartItemQuantity(item.id, item.quantity + 1)}
                            onDecrease={() => item.quantity > 1 
                              ? updateCartItemQuantity(item.id, item.quantity - 1)
                              : removeFromCart(item.id)
                            }
                            onQuantityChange={(value) => updateCartItemQuantity(item.id, value)}
                            min={1}
                            max={item.product?.stock || 99}
                          />
                        </div>
                        <button 
                          className="text-gray-400 hover:text-red-500 ml-4" 
                          onClick={() => removeFromCart(item.id)}
                          aria-label="Remove item"
                        >
                          <i className="ri-delete-bin-line"></i>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm p-6 sticky top-24">
              <h2 className="text-xl font-medium mb-6">Order Summary</h2>
              
              <div className="space-y-4 mb-6">
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-medium">{formatCurrency(subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Shipping</span>
                  <span className="font-medium">
                    {shipping === 0 ? 'Free' : formatCurrency(shipping)}
                  </span>
                </div>
                <div className="border-t pt-4 mt-4">
                  <div className="flex justify-between font-bold">
                    <span>Total</span>
                    <span>{formatCurrency(total)}</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Including taxes and duties
                  </p>
                </div>
              </div>
              
              <Button
                className="w-full bg-gold hover:bg-gold-dark text-white font-medium py-4 rounded-lg transition-colors"
                onClick={handleCheckout}
                disabled={isProcessing}
              >
                {isProcessing ? (
                  <span className="flex items-center justify-center">
                    <i className="ri-loader-4-line animate-spin mr-2"></i>
                    Processing...
                  </span>
                ) : (
                  'Proceed to Checkout'
                )}
              </Button>
              
              <div className="flex justify-center mt-4">
                <Link 
                  href="/products"
                  className="text-sm text-gray-500 hover:text-gold flex items-center"
                >
                  <i className="ri-arrow-left-line mr-1"></i>
                  Continue Shopping
                </Link>
              </div>
              
              <div className="mt-6 pt-6 border-t">
                <h3 className="font-medium mb-2">We Accept</h3>
                <div className="flex space-x-2">
                  <i className="ri-visa-line text-gray-400 text-xl"></i>
                  <i className="ri-mastercard-line text-gray-400 text-xl"></i>
                  <i className="ri-paypal-line text-gray-400 text-xl"></i>
                  <i className="ri-apple-line text-gray-400 text-xl"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <Newsletter />
      </div>
    </>
  );
};

export default CartPage;
