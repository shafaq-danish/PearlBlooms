import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Product, Category } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { formatCurrency } from '@/lib/utils';

export default function AdminDashboardPage() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('products');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [productForm, setProductForm] = useState({
    name: '',
    description: '',
    price: 0,
    categoryId: 1,
    images: [''],
    featured: false,
    new: false,
    stock: 0,
    variants: null
  });

  // Fetch products
  const { data: products, isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  // Fetch categories
  const { data: categories, isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  // Update product mutation
  const updateProductMutation = useMutation({
    mutationFn: async (product: Partial<Product>) => {
      if (!editingProduct) return null;
      return apiRequest(`/api/products/${editingProduct.id}`, {
        method: 'PATCH',
        body: JSON.stringify(product)
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      setEditingProduct(null);
      toast({
        title: "Success",
        description: "Product updated successfully",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update product: ${error}`,
        variant: "destructive",
      });
    }
  });

  // Add product mutation
  const addProductMutation = useMutation({
    mutationFn: async (product: Omit<Product, 'id' | 'createdAt'>) => {
      return apiRequest('/api/products', {
        method: 'POST',
        body: JSON.stringify(product)
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      setIsAddingProduct(false);
      resetProductForm();
      toast({
        title: "Success",
        description: "Product added successfully",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add product: ${error}`,
        variant: "destructive",
      });
    }
  });

  // Delete product mutation
  const deleteProductMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/products/${id}`, {
        method: 'DELETE'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      toast({
        title: "Success",
        description: "Product deleted successfully",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete product: ${error}`,
        variant: "destructive",
      });
    }
  });

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
  };

  const handleUpdateProduct = () => {
    if (!editingProduct) return;
    updateProductMutation.mutate(editingProduct);
  };

  const handleAddProduct = () => {
    // Format the productForm to match expected API format
    const newProduct = {
      ...productForm,
      price: Number(productForm.price),
      categoryId: Number(productForm.categoryId),
      stock: Number(productForm.stock),
    };
    
    addProductMutation.mutate(newProduct as any);
  };

  const handleDeleteProduct = (id: number) => {
    if (confirm('Are you sure you want to delete this product?')) {
      deleteProductMutation.mutate(id);
    }
  };

  const resetProductForm = () => {
    setProductForm({
      name: '',
      description: '',
      price: 0,
      categoryId: 1,
      images: [''],
      featured: false,
      new: false,
      stock: 0,
      variants: null
    });
  };

  // Helper function to handle product form changes
  const handleProductFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setProductForm(prev => ({
        ...prev,
        [name]: checked
      }));
      return;
    }
    
    setProductForm(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Helper function to handle editing product changes
  const handleEditingProductChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    if (!editingProduct) return;
    
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setEditingProduct(prev => ({
        ...prev!,
        [name]: checked
      }));
      return;
    }
    
    setEditingProduct(prev => ({
      ...prev!,
      [name]: value
    }));
  };

  // Helper function to handle image URL changes
  const handleImageChange = (index: number, value: string) => {
    setProductForm(prev => {
      const newImages = [...prev.images];
      newImages[index] = value;
      return {
        ...prev,
        images: newImages
      };
    });
  };

  // Helper function to add a new image input field
  const addImageField = () => {
    setProductForm(prev => ({
      ...prev,
      images: [...prev.images, '']
    }));
  };

  // Helper function to remove an image input field
  const removeImageField = (index: number) => {
    setProductForm(prev => {
      const newImages = prev.images.filter((_, i) => i !== index);
      return {
        ...prev,
        images: newImages.length ? newImages : ['']
      };
    });
  };

  // Helper function to handle editing product image changes
  const handleEditingProductImageChange = (index: number, value: string) => {
    if (!editingProduct) return;
    
    setEditingProduct(prev => {
      const newImages = [...prev!.images];
      newImages[index] = value;
      return {
        ...prev!,
        images: newImages
      };
    });
  };

  // Helper function to add a new image input field for editing product
  const addEditingProductImageField = () => {
    if (!editingProduct) return;
    
    setEditingProduct(prev => ({
      ...prev!,
      images: [...prev!.images, '']
    }));
  };

  // Helper function to remove an image input field for editing product
  const removeEditingProductImageField = (index: number) => {
    if (!editingProduct) return;
    
    setEditingProduct(prev => {
      const newImages = prev!.images.filter((_, i) => i !== index);
      return {
        ...prev!,
        images: newImages.length ? newImages : ['']
      };
    });
  };

  if (productsLoading || categoriesLoading) {
    return <div className="container py-8">Loading dashboard...</div>;
  }

  return (
    <div className="container py-8">
      <Helmet>
        <title>Admin Dashboard | Pearl Blooms</title>
        <meta name="description" content="Manage your store's products and content" />
      </Helmet>

      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <p className="text-muted-foreground">Manage your store's content</p>
      </div>

      <Tabs defaultValue="products" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-8">
          <TabsTrigger value="products">Products</TabsTrigger>
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
        </TabsList>

        <TabsContent value="products" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-semibold">Product Management</h2>
            <Dialog open={isAddingProduct} onOpenChange={setIsAddingProduct}>
              <DialogTrigger asChild>
                <Button>Add New Product</Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Add New Product</DialogTitle>
                  <DialogDescription>
                    Create a new product for your store. Fill in all the details below.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right font-medium">Name</label>
                    <Input
                      name="name"
                      value={productForm.name}
                      onChange={handleProductFormChange}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-start gap-4">
                    <label className="text-right font-medium">Description</label>
                    <Textarea
                      name="description"
                      value={productForm.description}
                      onChange={handleProductFormChange}
                      className="col-span-3 h-24"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right font-medium">Price</label>
                    <Input
                      type="number"
                      name="price"
                      value={productForm.price}
                      onChange={handleProductFormChange}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right font-medium">Category</label>
                    <Select
                      name="categoryId"
                      value={String(productForm.categoryId)}
                      onValueChange={(value) => setProductForm(prev => ({ ...prev, categoryId: Number(value) }))}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories?.map(category => (
                          <SelectItem key={category.id} value={String(category.id)}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right font-medium">Stock</label>
                    <Input
                      type="number"
                      name="stock"
                      value={productForm.stock}
                      onChange={handleProductFormChange}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right font-medium">Featured</label>
                    <div className="col-span-3">
                      <input
                        type="checkbox"
                        name="featured"
                        checked={productForm.featured}
                        onChange={handleProductFormChange}
                        className="mr-2"
                      />
                      <span>Display as featured product</span>
                    </div>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right font-medium">New</label>
                    <div className="col-span-3">
                      <input
                        type="checkbox"
                        name="new"
                        checked={productForm.new}
                        onChange={handleProductFormChange}
                        className="mr-2"
                      />
                      <span>Mark as new product</span>
                    </div>
                  </div>
                  <Separator className="my-2" />
                  <h3 className="font-semibold">Product Images</h3>
                  <div className="space-y-2">
                    {productForm.images.map((image, index) => (
                      <div key={index} className="flex gap-2">
                        <Input
                          value={image}
                          onChange={(e) => handleImageChange(index, e.target.value)}
                          placeholder="Image URL"
                          className="flex-1"
                        />
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => removeImageField(index)}
                          disabled={productForm.images.length === 1}
                        >
                          ✕
                        </Button>
                      </div>
                    ))}
                    <Button variant="outline" onClick={addImageField} className="w-full">
                      Add Image URL
                    </Button>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAddingProduct(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddProduct} disabled={addProductMutation.isPending}>
                    {addProductMutation.isPending ? 'Adding...' : 'Add Product'}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Stock</TableHead>
                  <TableHead>Featured</TableHead>
                  <TableHead>New</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {products?.map((product) => (
                  <TableRow key={product.id}>
                    <TableCell>{product.id}</TableCell>
                    <TableCell className="font-medium">{product.name}</TableCell>
                    <TableCell>{formatCurrency(product.price)}</TableCell>
                    <TableCell>
                      {categories?.find(c => c.id === product.categoryId)?.name || 'Unknown'}
                    </TableCell>
                    <TableCell>{product.stock}</TableCell>
                    <TableCell>{product.featured ? 'Yes' : 'No'}</TableCell>
                    <TableCell>{product.new ? 'Yes' : 'No'}</TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Dialog open={editingProduct?.id === product.id} onOpenChange={(open) => !open && setEditingProduct(null)}>
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm" onClick={() => handleEditProduct(product)}>
                              Edit
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                            <DialogHeader>
                              <DialogTitle>Edit Product</DialogTitle>
                              <DialogDescription>
                                Make changes to product information below.
                              </DialogDescription>
                            </DialogHeader>
                            {editingProduct && (
                              <div className="grid gap-4 py-4">
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <label className="text-right font-medium">Name</label>
                                  <Input
                                    name="name"
                                    value={editingProduct.name}
                                    onChange={handleEditingProductChange}
                                    className="col-span-3"
                                  />
                                </div>
                                <div className="grid grid-cols-4 items-start gap-4">
                                  <label className="text-right font-medium">Description</label>
                                  <Textarea
                                    name="description"
                                    value={editingProduct.description}
                                    onChange={handleEditingProductChange}
                                    className="col-span-3 h-24"
                                  />
                                </div>
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <label className="text-right font-medium">Price</label>
                                  <Input
                                    type="number"
                                    name="price"
                                    value={editingProduct.price}
                                    onChange={(e) => setEditingProduct(prev => ({ ...prev!, price: Number(e.target.value) }))}
                                    className="col-span-3"
                                  />
                                </div>
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <label className="text-right font-medium">Category</label>
                                  <Select
                                    value={String(editingProduct.categoryId)}
                                    onValueChange={(value) => setEditingProduct(prev => ({ ...prev!, categoryId: Number(value) }))}
                                  >
                                    <SelectTrigger className="col-span-3">
                                      <SelectValue placeholder="Select a category" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {categories?.map(category => (
                                        <SelectItem key={category.id} value={String(category.id)}>
                                          {category.name}
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                </div>
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <label className="text-right font-medium">Stock</label>
                                  <Input
                                    type="number"
                                    name="stock"
                                    value={editingProduct.stock}
                                    onChange={(e) => setEditingProduct(prev => ({ ...prev!, stock: Number(e.target.value) }))}
                                    className="col-span-3"
                                  />
                                </div>
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <label className="text-right font-medium">Featured</label>
                                  <div className="col-span-3">
                                    <input
                                      type="checkbox"
                                      name="featured"
                                      checked={editingProduct.featured}
                                      onChange={handleEditingProductChange}
                                      className="mr-2"
                                    />
                                    <span>Display as featured product</span>
                                  </div>
                                </div>
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <label className="text-right font-medium">New</label>
                                  <div className="col-span-3">
                                    <input
                                      type="checkbox"
                                      name="new"
                                      checked={editingProduct.new}
                                      onChange={handleEditingProductChange}
                                      className="mr-2"
                                    />
                                    <span>Mark as new product</span>
                                  </div>
                                </div>
                                <Separator className="my-2" />
                                <h3 className="font-semibold">Product Images</h3>
                                <div className="space-y-2">
                                  {editingProduct.images.map((image, index) => (
                                    <div key={index} className="flex gap-2">
                                      <Input
                                        value={image}
                                        onChange={(e) => handleEditingProductImageChange(index, e.target.value)}
                                        placeholder="Image URL"
                                        className="flex-1"
                                      />
                                      <Button
                                        variant="outline"
                                        size="icon"
                                        onClick={() => removeEditingProductImageField(index)}
                                        disabled={editingProduct.images.length === 1}
                                      >
                                        ✕
                                      </Button>
                                    </div>
                                  ))}
                                  <Button variant="outline" onClick={addEditingProductImageField} className="w-full">
                                    Add Image URL
                                  </Button>
                                </div>
                              </div>
                            )}
                            <DialogFooter>
                              <Button variant="outline" onClick={() => setEditingProduct(null)}>
                                Cancel
                              </Button>
                              <Button onClick={handleUpdateProduct} disabled={updateProductMutation.isPending}>
                                {updateProductMutation.isPending ? 'Saving...' : 'Save Changes'}
                              </Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>
                        <Button 
                          variant="destructive" 
                          size="sm" 
                          onClick={() => handleDeleteProduct(product.id)}
                          disabled={deleteProductMutation.isPending}
                        >
                          Delete
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="categories" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Category Management</CardTitle>
              <CardDescription>
                Manage your store's product categories
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Slug</TableHead>
                      <TableHead>Image</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {categories?.map((category) => (
                      <TableRow key={category.id}>
                        <TableCell>{category.id}</TableCell>
                        <TableCell className="font-medium">{category.name}</TableCell>
                        <TableCell>{category.slug}</TableCell>
                        <TableCell>
                          <img 
                            src={category.image} 
                            alt={category.name} 
                            className="w-10 h-10 object-cover rounded"
                          />
                        </TableCell>
                        <TableCell>
                          <Button variant="outline" size="sm">
                            Edit
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline">Cancel</Button>
              <Button>Add Category</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="orders" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Order Management</CardTitle>
              <CardDescription>
                View and manage customer orders
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-center py-8 text-muted-foreground">Order management coming soon</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>User Management</CardTitle>
              <CardDescription>
                View and manage user accounts
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-center py-8 text-muted-foreground">User management coming soon</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}