import { useState } from "react";

interface ImageGalleryProps {
  images: string[];
  alt: string;
}

const ImageGallery = ({ images, alt }: ImageGalleryProps) => {
  const [mainImage, setMainImage] = useState(images[0]);
  const [activeIndex, setActiveIndex] = useState(0);

  const handleThumbnailClick = (image: string, index: number) => {
    setMainImage(image);
    setActiveIndex(index);
  };

  if (!images.length) {
    return (
      <div className="bg-gray-100 rounded-lg flex items-center justify-center h-80">
        <span className="text-gray-400">No image available</span>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-4 relative overflow-hidden rounded-lg">
        <img
          src={mainImage}
          alt={alt}
          className="w-full h-auto rounded-lg object-cover"
          style={{ maxHeight: "500px" }}
        />
        <div className="absolute top-4 right-4">
          <button
            className="bg-white hover:bg-gold text-gold hover:text-white w-10 h-10 rounded-full flex items-center justify-center transition-colors"
            aria-label="Add to wishlist"
          >
            <i className="ri-heart-line"></i>
          </button>
        </div>
      </div>
      {images.length > 1 && (
        <div className="grid grid-cols-4 gap-2">
          {images.map((image, index) => (
            <button
              key={index}
              className={`border-2 rounded-md overflow-hidden transition-all ${
                activeIndex === index ? "border-gold" : "border-transparent hover:border-gold"
              }`}
              onClick={() => handleThumbnailClick(image, index)}
            >
              <img
                src={image}
                alt={`${alt} - View ${index + 1}`}
                className="w-full h-auto object-cover"
                style={{ height: "80px" }}
              />
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default ImageGallery;
