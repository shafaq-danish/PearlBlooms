import { Button } from "@/components/ui/button";

interface QuantitySelectorProps {
  quantity: number;
  onIncrease: () => void;
  onDecrease: () => void;
  onQuantityChange: (value: number) => void;
  max?: number;
  min?: number;
}

const QuantitySelector = ({
  quantity,
  onIncrease,
  onDecrease,
  onQuantityChange,
  max = 99,
  min = 1,
}: QuantitySelectorProps) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (isNaN(value)) {
      onQuantityChange(min);
    } else {
      // Clamp value between min and max
      const clampedValue = Math.min(Math.max(value, min), max);
      onQuantityChange(clampedValue);
    }
  };

  return (
    <div className="flex border border-gray-300 rounded-lg">
      <Button
        type="button"
        variant="ghost"
        className="w-10 h-10 flex items-center justify-center hover:bg-gray-100 rounded-none rounded-l-lg"
        onClick={onDecrease}
        disabled={quantity <= min}
        aria-label="Decrease quantity"
      >
        <i className="ri-subtract-line"></i>
      </Button>
      <input
        type="number"
        min={min}
        max={max}
        value={quantity}
        onChange={handleInputChange}
        className="w-12 text-center border-0 focus:ring-0"
        aria-label="Quantity"
      />
      <Button
        type="button"
        variant="ghost"
        className="w-10 h-10 flex items-center justify-center hover:bg-gray-100 rounded-none rounded-r-lg"
        onClick={onIncrease}
        disabled={quantity >= max}
        aria-label="Increase quantity"
      >
        <i className="ri-add-line"></i>
      </Button>
    </div>
  );
};

export default QuantitySelector;
