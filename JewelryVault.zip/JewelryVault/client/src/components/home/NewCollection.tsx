import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Product } from "@/types";
import ProductCard from "@/components/product/ProductCard";

const NewCollection = () => {
  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ['/api/products', { new: true, limit: 3 }],
  });

  return (
    <section id="new-collection" className="py-16 bg-offwhite">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between mb-12">
          <h2 className="text-3xl md:text-4xl font-serif font-bold">New Collection</h2>
          <div className="mt-4 md:mt-0">
            <Link href="/products" className="flex items-center group">
              <span className="text-black-light group-hover:text-gold font-medium">View All</span>
              <i className="ri-arrow-right-line ml-2 group-hover:ml-3 transition-all text-gold"></i>
            </Link>
          </div>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {isLoading ? (
            // Loading skeleton
            [...Array(3)].map((_, index) => (
              <div key={index} className="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                <div className="animate-pulse">
                  <div className="h-80 bg-gray-200 w-full"></div>
                  <div className="p-5">
                    <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-gray-100 rounded w-1/2 mb-4"></div>
                    <div className="flex justify-between items-center">
                      <div className="h-5 bg-gray-200 rounded w-1/4"></div>
                      <div className="h-4 bg-gray-100 rounded w-1/4"></div>
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            products?.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))
          )}
        </div>
      </div>
    </section>
  );
};

export default NewCollection;
