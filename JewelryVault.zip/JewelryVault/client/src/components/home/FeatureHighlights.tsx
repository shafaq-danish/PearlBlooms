const FeatureHighlights = () => {
  const features = [
    {
      icon: "ri-award-line",
      title: "Premium Quality",
      description: "Each piece crafted with the finest materials and meticulous attention to detail."
    },
    {
      icon: "ri-shield-check-line",
      title: "Certified Authentic",
      description: "All gems and precious metals are authenticated and certified for your peace of mind."
    },
    {
      icon: "ri-truck-line",
      title: "Free Shipping",
      description: "Complimentary insured shipping on all orders over $500 worldwide."
    },
    {
      icon: "ri-refresh-line",
      title: "Easy Returns",
      description: "30-day hassle-free returns if you're not completely satisfied."
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-serif font-bold text-center mb-4">
          Why Choose Us
        </h2>
        <p className="text-center text-gray-600 max-w-2xl mx-auto mb-12">
          We're committed to excellence in every aspect of your jewelry experience
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center">
              <div className="mx-auto w-16 h-16 flex items-center justify-center bg-gold-light rounded-full mb-4">
                <i className={`${feature.icon} text-2xl text-gold`}></i>
              </div>
              <h3 className="text-xl font-medium mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeatureHighlights;
