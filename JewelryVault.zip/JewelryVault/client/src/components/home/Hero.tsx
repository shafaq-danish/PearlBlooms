import { Link } from "wouter";

const Hero = () => {
  return (
    <section className="relative h-screen">
      <div className="absolute inset-0 bg-black">
        <img 
          src="https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=2000&h=1200" 
          alt="Luxury diamond necklace" 
          className="w-full h-full object-cover opacity-85" 
        />
      </div>
      <div className="relative h-full flex items-center">
        <div className="container mx-auto px-4">
          <div className="max-w-lg ml-0 md:ml-12 slide-in">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-white leading-tight mb-4">
              Timeless Elegance Reimagined
            </h1>
            <p className="text-lg text-gold-light mb-8">
              Discover our exquisite new collection of handcrafted jewelry.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Link 
                href="/products"
                className="bg-gold hover:bg-gold-dark text-white font-medium py-3 px-6 transition-colors text-center"
              >
                Explore Collection
              </Link>
              <Link 
                href="#"
                className="border border-white text-white hover:bg-white hover:text-black font-medium py-3 px-6 transition-colors text-center"
              >
                Our Story
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
