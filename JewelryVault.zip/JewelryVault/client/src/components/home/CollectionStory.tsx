import { Link } from "wouter";

const CollectionStory = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1">
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">Crafted with Passion</h2>
            <p className="text-lg text-gray-700 mb-6">
              Every piece in our collection is meticulously handcrafted by master artisans with decades of experience. 
              We source only the finest ethically-obtained materials to create jewelry that stands the test of time.
            </p>
            <p className="text-lg text-gray-700 mb-8">
              From initial design to final polish, we ensure each creation meets our exacting standards of quality and elegance.
            </p>
            <Link 
              href="#"
              className="inline-block bg-gold hover:bg-gold-dark text-white font-medium py-3 px-6 transition-colors"
            >
              Our Craftsmanship
            </Link>
          </div>
          <div className="order-1 md:order-2">
            <img 
              src="https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=800&h=600" 
              alt="Jewelery craftsman at work" 
              className="w-full rounded-lg shadow-lg" 
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default CollectionStory;
