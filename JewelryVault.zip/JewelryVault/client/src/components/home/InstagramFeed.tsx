const InstagramFeed = () => {
  const instagramPosts = [
    {
      image: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=400&h=400",
      alt: "Instagram post - jewelry collection"
    },
    {
      image: "https://images.unsplash.com/photo-1543294001-f7cd5d7fb516?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=400&h=400",
      alt: "Instagram post - diamond ring"
    },
    {
      image: "https://images.unsplash.com/photo-1611591437281-460bfbe1220a?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=400&h=400",
      alt: "Instagram post - bracelet"
    },
    {
      image: "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=400&h=400",
      alt: "Instagram post - jewelry making"
    },
    {
      image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=400&h=400",
      alt: "Instagram post - necklace display"
    },
    {
      image: "https://images.unsplash.com/photo-1602173574767-37ac01994b2a?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=400&h=400",
      alt: "Instagram post - earrings"
    }
  ];

  return (
    <section className="py-16 bg-offwhite">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between mb-12">
          <h2 className="text-3xl md:text-4xl font-serif font-bold">Follow Our Journey</h2>
          <a href="#" className="flex items-center mt-4 md:mt-0 group">
            <i className="ri-instagram-line mr-2 text-gold"></i>
            <span className="text-black-light group-hover:text-gold font-medium">@lumiere_jewelry</span>
          </a>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {instagramPosts.map((post, index) => (
            <a 
              key={index}
              href="#" 
              className="block overflow-hidden rounded-lg group"
            >
              <img 
                src={post.image} 
                alt={post.alt} 
                className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-110" 
              />
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};

export default InstagramFeed;
