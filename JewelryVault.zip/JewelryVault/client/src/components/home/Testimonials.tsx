import { useQuery } from "@tanstack/react-query";
import { Testimonial } from "@/types";

// Star rating component
const StarRating = ({ rating }: { rating: number }) => {
  return (
    <div className="flex text-gold mb-4">
      {[...Array(5)].map((_, index) => {
        const ratingValue = index + 1;
        return (
          <i 
            key={index} 
            className={
              ratingValue <= rating
                ? "ri-star-fill"
                : ratingValue <= rating + 0.5
                ? "ri-star-half-fill"
                : "ri-star-line"
            }
          ></i>
        );
      })}
    </div>
  );
};

const Testimonials = () => {
  const { data: testimonials, isLoading } = useQuery<Testimonial[]>({
    queryKey: ['/api/testimonials', { featured: true }],
  });

  return (
    <section className="py-16 bg-gold-light">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-serif font-bold text-center mb-12">
          Client Testimonials
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {isLoading ? (
            // Loading skeleton
            [...Array(3)].map((_, index) => (
              <div key={index} className="bg-white p-8 rounded-lg shadow-sm animate-pulse">
                <div className="h-4 bg-gray-200 w-1/3 mb-6"></div>
                <div className="h-4 bg-gray-200 w-full mb-2"></div>
                <div className="h-4 bg-gray-200 w-full mb-2"></div>
                <div className="h-4 bg-gray-200 w-3/4 mb-6"></div>
                <div className="flex items-center">
                  <div className="w-12 h-12 rounded-full bg-gray-200 mr-4"></div>
                  <div>
                    <div className="h-4 bg-gray-200 w-24 mb-1"></div>
                    <div className="h-3 bg-gray-200 w-32"></div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            testimonials?.map((testimonial) => (
              <div key={testimonial.id} className="bg-white p-8 rounded-lg shadow-sm">
                <StarRating rating={testimonial.rating} />
                <p className="text-gray-700 mb-6">{testimonial.content}</p>
                <div className="flex items-center">
                  <div className="w-12 h-12 rounded-full bg-gray-200 overflow-hidden mr-4">
                    {testimonial.avatar ? (
                      <img 
                        src={testimonial.avatar} 
                        alt={testimonial.name} 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full bg-gold-light flex items-center justify-center text-gold">
                        <span className="font-medium">
                          {testimonial.name.split(' ').map(n => n[0]).join('')}
                        </span>
                      </div>
                    )}
                  </div>
                  <div>
                    <h4 className="font-medium">{testimonial.name}</h4>
                    <p className="text-sm text-gray-500">{testimonial.location}</p>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
