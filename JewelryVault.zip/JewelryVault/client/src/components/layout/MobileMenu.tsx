import { Link, useLocation } from "wouter";
import { useEffect } from "react";

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const MobileMenu = ({ isOpen, onClose }: MobileMenuProps) => {
  const [location] = useLocation();

  // Close mobile menu when location changes
  useEffect(() => {
    if (isOpen) {
      onClose();
    }
  }, [location, isOpen, onClose]);

  // Prevent body scroll when menu is open
  useEffect(() => {
    if (isOpen) {
      document.body.classList.add("overflow-hidden");
    } else {
      document.body.classList.remove("overflow-hidden");
    }
    
    return () => {
      document.body.classList.remove("overflow-hidden");
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black bg-opacity-50">
      <div className="fixed inset-y-0 right-0 w-full sm:w-80 bg-white shadow-lg transform transition-transform duration-300">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-medium">Menu</h2>
          <button
            className="text-black hover:text-gold transition"
            onClick={onClose}
            aria-label="Close menu"
          >
            <i className="ri-close-line text-2xl"></i>
          </button>
        </div>
        
        <nav className="p-4">
          <div className="flex flex-col space-y-4">
            <Link href="/" className="font-medium text-black hover:text-gold py-2 border-b border-gray-100">
              Home
            </Link>
            <Link href="/products" className="font-medium text-black hover:text-gold py-2 border-b border-gray-100">
              Collections
            </Link>
            <Link href="/products/rings" className="font-medium text-black hover:text-gold py-2 border-b border-gray-100">
              Rings
            </Link>
            <Link href="/products/necklaces" className="font-medium text-black hover:text-gold py-2 border-b border-gray-100">
              Necklaces
            </Link>
            <Link href="/products/earrings" className="font-medium text-black hover:text-gold py-2 border-b border-gray-100">
              Earrings
            </Link>
            <Link href="/products/bracelets" className="font-medium text-black hover:text-gold py-2 border-b border-gray-100">
              Bracelets
            </Link>
          </div>
          
          <div className="mt-8">
            <h3 className="font-medium text-gray-500 mb-2">Account</h3>
            <div className="flex flex-col space-y-4">
              <Link href="/login" className="text-black hover:text-gold py-2">
                <i className="ri-user-line mr-2"></i>
                Login / Register
              </Link>
              <Link href="/wishlist" className="text-black hover:text-gold py-2">
                <i className="ri-heart-line mr-2"></i>
                Wishlist
              </Link>
              <Link href="/cart" className="text-black hover:text-gold py-2">
                <i className="ri-shopping-bag-line mr-2"></i>
                Shopping Cart
              </Link>
            </div>
          </div>
        </nav>
      </div>
    </div>
  );
};

export default MobileMenu;
