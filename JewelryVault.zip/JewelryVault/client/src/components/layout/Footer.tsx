import { Link } from "wouter";

const Footer = () => {
  return (
    <footer className="bg-black text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
          <div className="lg:col-span-2">
            <Link href="/" className="text-2xl font-serif font-bold mb-4 inline-block">
              LUMIÈRE
            </Link>
            <p className="text-gray-400 mb-6 max-w-md">
              Crafting timeless jewelry that celebrates life's most precious moments.
              Each piece tells a unique story.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-gold transition-colors" aria-label="Instagram">
                <i className="ri-instagram-line text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-gold transition-colors" aria-label="Facebook">
                <i className="ri-facebook-fill text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-gold transition-colors" aria-label="Pinterest">
                <i className="ri-pinterest-line text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-gold transition-colors" aria-label="Twitter">
                <i className="ri-twitter-x-line text-xl"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-4">Shop</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/products" className="text-gray-400 hover:text-gold transition-colors">
                  New Arrivals
                </Link>
              </li>
              <li>
                <Link href="/products" className="text-gray-400 hover:text-gold transition-colors">
                  Best Sellers
                </Link>
              </li>
              <li>
                <Link href="/products/rings" className="text-gray-400 hover:text-gold transition-colors">
                  Rings
                </Link>
              </li>
              <li>
                <Link href="/products/necklaces" className="text-gray-400 hover:text-gold transition-colors">
                  Necklaces
                </Link>
              </li>
              <li>
                <Link href="/products/earrings" className="text-gray-400 hover:text-gold transition-colors">
                  Earrings
                </Link>
              </li>
              <li>
                <Link href="/products/bracelets" className="text-gray-400 hover:text-gold transition-colors">
                  Bracelets
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-4">About</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="text-gray-400 hover:text-gold transition-colors">
                  Our Story
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-gold transition-colors">
                  Craftsmanship
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-gold transition-colors">
                  Materials
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-gold transition-colors">
                  Sustainability
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-gold transition-colors">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-gold transition-colors">
                  Press
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-4">Customer Care</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="text-gray-400 hover:text-gold transition-colors">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-gold transition-colors">
                  Shipping & Returns
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-gold transition-colors">
                  Warranty
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-gold transition-colors">
                  Care Guide
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-gold transition-colors">
                  FAQs
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-gold transition-colors">
                  Size Guide
                </Link>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <p className="text-gray-500 text-sm">
                &copy; {new Date().getFullYear()} LUMIÈRE Jewelry. All rights reserved.
              </p>
            </div>
            
            <div className="flex flex-wrap justify-center space-x-4">
              <Link href="#" className="text-gray-500 hover:text-gray-300 text-sm">
                Privacy Policy
              </Link>
              <Link href="#" className="text-gray-500 hover:text-gray-300 text-sm">
                Terms of Service
              </Link>
              <Link href="#" className="text-gray-500 hover:text-gray-300 text-sm">
                Accessibility
              </Link>
            </div>
            
            <div className="mt-4 md:mt-0 flex items-center">
              <span className="text-gray-500 text-sm mr-2">Payment Methods:</span>
              <div className="flex space-x-2">
                <i className="ri-visa-line text-gray-400"></i>
                <i className="ri-mastercard-line text-gray-400"></i>
                <i className="ri-paypal-line text-gray-400"></i>
                <i className="ri-apple-line text-gray-400"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
