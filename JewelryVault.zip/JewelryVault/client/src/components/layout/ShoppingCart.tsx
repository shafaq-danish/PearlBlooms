import { useEffect, useMemo } from "react";
import { Link } from "wouter";
import { useCart } from "@/hooks/useCart";
import { formatCurrency } from "@/lib/utils";

interface ShoppingCartProps {
  isOpen: boolean;
  onClose: () => void;
}

const ShoppingCart = ({ isOpen, onClose }: ShoppingCartProps) => {
  const { cartItems, removeFromCart, updateCartItemQuantity, isLoading } = useCart();

  // Calculate cart totals
  const subtotal = useMemo(() => 
    cartItems.reduce((total, item) => 
      total + (item.product?.price || 0) * item.quantity, 0
    ), [cartItems]
  );

  // Prevent body scroll when cart is open
  useEffect(() => {
    if (isOpen) {
      document.body.classList.add("overflow-hidden");
    } else {
      document.body.classList.remove("overflow-hidden");
    }
    
    return () => {
      document.body.classList.remove("overflow-hidden");
    };
  }, [isOpen]);

  const handleIncreaseQuantity = (id: number, quantity: number) => {
    updateCartItemQuantity(id, quantity + 1);
  };

  const handleDecreaseQuantity = (id: number, quantity: number) => {
    if (quantity > 1) {
      updateCartItemQuantity(id, quantity - 1);
    } else {
      removeFromCart(id);
    }
  };

  return (
    <div 
      className={`fixed inset-y-0 right-0 w-full sm:w-96 bg-white shadow-lg z-50 transform transition-transform duration-300 ${
        isOpen ? "translate-x-0" : "translate-x-full"
      }`}
    >
      <div className="flex flex-col h-full">
        <div className="p-4 border-b flex justify-between items-center">
          <h2 className="text-xl font-medium">Your Cart ({cartItems.length})</h2>
          <button 
            className="text-black hover:text-gold transition"
            onClick={onClose}
            aria-label="Close cart"
          >
            <i className="ri-close-line text-2xl"></i>
          </button>
        </div>
        
        <div className="flex-grow overflow-y-auto custom-scrollbar p-4">
          {isLoading ? (
            <div className="flex items-center justify-center h-32">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-gold"></div>
            </div>
          ) : cartItems.length === 0 ? (
            <div className="text-center py-8">
              <i className="ri-shopping-bag-line text-4xl text-gray-300 mb-2"></i>
              <p className="text-gray-500">Your cart is empty</p>
              <Link href="/products" onClick={onClose} className="text-gold hover:underline mt-2 inline-block">
                Continue Shopping
              </Link>
            </div>
          ) : (
            cartItems.map((item) => (
              <div key={item.id} className="flex border-b pb-4 mb-4">
                <div className="w-20 h-20 rounded-md overflow-hidden mr-4">
                  <img 
                    src={item.product?.images[0]} 
                    alt={item.product?.name} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-grow">
                  <h3 className="font-medium">{item.product?.name}</h3>
                  {item.variant && (
                    <p className="text-sm text-gray-500">{item.variant}</p>
                  )}
                  <div className="flex justify-between items-center mt-2">
                    <div className="flex items-center">
                      <button 
                        className="text-gray-500 hover:text-gold"
                        onClick={() => handleDecreaseQuantity(item.id, item.quantity)}
                      >
                        <i className="ri-subtract-line"></i>
                      </button>
                      <span className="mx-2 w-6 text-center">{item.quantity}</span>
                      <button 
                        className="text-gray-500 hover:text-gold"
                        onClick={() => handleIncreaseQuantity(item.id, item.quantity)}
                      >
                        <i className="ri-add-line"></i>
                      </button>
                    </div>
                    <span className="font-medium">
                      {formatCurrency((item.product?.price || 0) * item.quantity)}
                    </span>
                  </div>
                </div>
                <button 
                  className="ml-2 text-gray-400 hover:text-red-500" 
                  onClick={() => removeFromCart(item.id)}
                  aria-label="Remove item"
                >
                  <i className="ri-delete-bin-line"></i>
                </button>
              </div>
            ))
          )}
        </div>
        
        {cartItems.length > 0 && (
          <div className="p-4 border-t">
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-600">Subtotal</span>
              <span className="font-medium">{formatCurrency(subtotal)}</span>
            </div>
            <div className="flex justify-between items-center mb-2 text-sm text-gray-500">
              <span>Shipping</span>
              <span>Calculated at checkout</span>
            </div>
            <div className="flex justify-between items-center mb-4 font-bold text-lg">
              <span>Total</span>
              <span>{formatCurrency(subtotal)}</span>
            </div>
            
            <div className="grid gap-3">
              <Link 
                href="/checkout"
                className="w-full bg-gold hover:bg-gold-dark text-white font-medium py-3 rounded-lg transition-colors text-center"
                onClick={onClose}
              >
                Proceed to Checkout
              </Link>
              <button 
                className="w-full bg-white border border-black hover:bg-gray-50 text-black font-medium py-3 rounded-lg transition-colors"
                onClick={onClose}
              >
                Continue Shopping
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ShoppingCart;
