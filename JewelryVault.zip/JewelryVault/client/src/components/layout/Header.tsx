import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { useCart } from "@/hooks/useCart";
import ShoppingCart from "./ShoppingCart";
import MobileMenu from "./MobileMenu";

const Header = () => {
  const [location] = useLocation();
  const { user } = useAuth();
  const { cartItems } = useCart();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const cartItemsCount = cartItems.reduce((total, item) => total + item.quantity, 0);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      <header className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white bg-opacity-95 shadow-sm' : 'bg-white'}`}>
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center py-4">
            {/* Logo */}
            <Link href="/" className="text-2xl md:text-3xl font-serif font-bold text-black">
              Pearl Blooms
            </Link>
            
            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              <Link href="/" className={`nav-item ${location === '/' ? 'text-gold' : ''}`}>
                Home
              </Link>
              <Link href="/products" className={`nav-item ${location === '/products' ? 'text-gold' : ''}`}>
                Collections
              </Link>
              <Link href="/products/rings" className={`nav-item ${location === '/products/rings' ? 'text-gold' : ''}`}>
                Rings
              </Link>
              <Link href="/products/necklaces" className={`nav-item ${location === '/products/necklaces' ? 'text-gold' : ''}`}>
                Necklaces
              </Link>
              <Link href="/products/earrings" className={`nav-item ${location === '/products/earrings' ? 'text-gold' : ''}`}>
                Earrings
              </Link>
              <Link href="/products/bracelets" className={`nav-item ${location === '/products/bracelets' ? 'text-gold' : ''}`}>
                Bracelets
              </Link>
            </nav>
            
            {/* Icons */}
            <div className="flex items-center space-x-4">
              <Link href="/products" className="text-black hover:text-gold transition" aria-label="Search">
                <i className="ri-search-line text-xl"></i>
              </Link>
              
              <Link href={user ? "/account" : "/login"} className="text-black hover:text-gold transition" aria-label="User Account">
                <i className="ri-user-line text-xl"></i>
              </Link>
              
              <Link href="/wishlist" className="text-black hover:text-gold transition" aria-label="Wishlist">
                <i className="ri-heart-line text-xl"></i>
              </Link>

              <Link href="/dashboard" className="text-black hover:text-gold transition" aria-label="Complete Dashboard">
                <i className="ri-dashboard-line text-xl"></i>
              </Link>
              
              <button
                className="text-black hover:text-gold transition relative"
                aria-label="Shopping Cart"
                onClick={() => setIsCartOpen(true)}
              >
                <i className="ri-shopping-bag-line text-xl"></i>
                {cartItemsCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-gold text-white text-xs w-4 h-4 flex items-center justify-center rounded-full">
                    {cartItemsCount}
                  </span>
                )}
              </button>
              
              <button
                className="md:hidden text-black hover:text-gold transition"
                onClick={() => setIsMobileMenuOpen(true)}
                aria-label="Menu"
              >
                <i className="ri-menu-line text-xl"></i>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <MobileMenu isOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />

      {/* Shopping Cart */}
      <ShoppingCart isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
    </>
  );
};

export default Header;
