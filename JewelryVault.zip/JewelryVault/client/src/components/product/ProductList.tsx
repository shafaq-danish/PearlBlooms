import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Product } from "@/types";
import ProductCard from "./ProductCard";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";

interface ProductListProps {
  categoryId?: number;
  featured?: boolean;
  limit?: number;
  title?: string;
  showFilters?: boolean;
}

const ProductList = ({
  categoryId,
  featured,
  limit,
  title = "Products",
  showFilters = true,
}: ProductListProps) => {
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState("newest");
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);

  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: [
      "/api/products",
      { categoryId, featured, limit, search: search.length >= 3 ? search : undefined },
    ],
  });

  useEffect(() => {
    if (!products) return;

    // Apply sorting
    let sorted = [...products];
    switch (sortBy) {
      case "price-low":
        sorted.sort((a, b) => a.price - b.price);
        break;
      case "price-high":
        sorted.sort((a, b) => b.price - a.price);
        break;
      case "rating":
        sorted.sort((a, b) => b.rating - a.rating);
        break;
      case "newest":
      default:
        // Already sorted by newest in the API
        break;
    }

    setFilteredProducts(sorted);
  }, [products, sortBy]);

  // Loading skeleton
  if (isLoading) {
    return (
      <div>
        {title && (
          <h2 className="text-3xl md:text-4xl font-serif font-bold mb-8">
            {title}
          </h2>
        )}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {[...Array(limit || 6)].map((_, index) => (
            <div
              key={index}
              className="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow animate-pulse"
            >
              <div className="h-80 bg-gray-200 w-full"></div>
              <div className="p-5">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-gray-100 rounded w-1/2 mb-4"></div>
                <div className="flex justify-between items-center">
                  <div className="h-5 bg-gray-200 rounded w-1/4"></div>
                  <div className="h-4 bg-gray-100 rounded w-1/4"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // No products found
  if (!filteredProducts || filteredProducts.length === 0) {
    return (
      <div>
        {title && (
          <h2 className="text-3xl md:text-4xl font-serif font-bold mb-8">
            {title}
          </h2>
        )}
        {showFilters && (
          <div className="mb-8 flex flex-col sm:flex-row gap-4">
            <div className="flex-grow">
              <Input
                type="search"
                placeholder="Search products..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full"
              />
            </div>
            <div className="w-full sm:w-48">
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger>
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="rating">Rating</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        )}
        <div className="flex flex-col items-center justify-center py-16 bg-white rounded-lg shadow-sm">
          <i className="ri-shopping-bag-3-line text-4xl text-gray-300 mb-4"></i>
          <h3 className="text-xl font-medium mb-2">No products found</h3>
          <p className="text-gray-500 mb-4">
            We couldn't find any products matching your criteria.
          </p>
          {search && (
            <Button
              variant="outline"
              onClick={() => setSearch("")}
              className="mt-2"
            >
              Clear Search
            </Button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div>
      {title && (
        <h2 className="text-3xl md:text-4xl font-serif font-bold mb-8">
          {title}
        </h2>
      )}
      {showFilters && (
        <div className="mb-8 flex flex-col sm:flex-row gap-4">
          <div className="flex-grow">
            <Input
              type="search"
              placeholder="Search products..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full"
            />
          </div>
          <div className="w-full sm:w-48">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger>
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
                <SelectItem value="rating">Rating</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      )}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredProducts.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
};

export default ProductList;
