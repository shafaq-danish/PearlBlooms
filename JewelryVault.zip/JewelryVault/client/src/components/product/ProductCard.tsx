import { useState } from "react";
import { Link } from "wouter";
import { Product } from "@/types";
import { useCart } from "@/hooks/useCart";
import { useWishlist } from "@/hooks/useWishlist";
import { useAuth } from "@/context/AuthContext";
import { formatCurrency } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import ProductDetail from "./ProductDetail";

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  const { addToCart } = useCart();
  const { addToWishlist, isInWishlist } = useWishlist();
  const { user } = useAuth();
  const { toast } = useToast();
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!user) {
      toast({
        title: "Please login",
        description: "You need to be logged in to add items to your cart",
        variant: "destructive",
      });
      return;
    }
    
    addToCart(product.id);
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart`,
    });
  };

  const handleAddToWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!user) {
      toast({
        title: "Please login",
        description: "You need to be logged in to add items to your wishlist",
        variant: "destructive",
      });
      return;
    }
    
    addToWishlist(product.id);
    toast({
      title: "Added to wishlist",
      description: `${product.name} has been added to your wishlist`,
    });
  };

  const handleQuickView = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDetailOpen(true);
  };

  return (
    <>
      <div className="product-card group bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
        <Link href={`/product/${product.id}`}>
          <div className="relative overflow-hidden">
            <img 
              src={product.images[0]} 
              alt={product.name} 
              className="product-image w-full h-72 md:h-80 object-cover" 
            />
            <div className="absolute top-4 right-4 flex flex-col space-y-2">
              <button 
                className="bg-white hover:bg-gold text-gold hover:text-white w-10 h-10 rounded-full flex items-center justify-center transition-colors" 
                aria-label="Add to wishlist"
                onClick={handleAddToWishlist}
              >
                <i className={isInWishlist(product.id) ? "ri-heart-fill" : "ri-heart-line"}></i>
              </button>
              <button 
                className="bg-white hover:bg-gold text-gold hover:text-white w-10 h-10 rounded-full flex items-center justify-center transition-colors" 
                aria-label="Quick view"
                onClick={handleQuickView}
              >
                <i className="ri-eye-line"></i>
              </button>
            </div>
            <div className="absolute bottom-0 left-0 w-full py-3 px-4 bg-gradient-to-t from-black to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
              <button 
                className="w-full bg-gold hover:bg-gold-dark text-white font-medium py-2 px-4 transition-colors"
                onClick={handleAddToCart}
              >
                Add to Cart
              </button>
            </div>
          </div>
          <div className="p-5">
            <h3 className="text-lg font-medium mb-1">{product.name}</h3>
            <p className="text-gray-600 text-sm mb-2">{product.categoryId === 1 ? 'Rings' : product.categoryId === 2 ? 'Necklaces' : product.categoryId === 3 ? 'Earrings' : 'Bracelets'} Collection</p>
            <div className="flex justify-between items-center">
              <span className="text-xl font-semibold text-black">{formatCurrency(product.price)}</span>
              <div className="flex items-center">
                <div className="flex text-gold">
                  {/* Show full stars */}
                  {[...Array(Math.floor(product.rating))].map((_, i) => (
                    <i key={i} className="ri-star-fill"></i>
                  ))}
                  
                  {/* Show half star if needed */}
                  {product.rating % 1 >= 0.5 && <i className="ri-star-half-fill"></i>}
                  
                  {/* Show empty stars */}
                  {[...Array(5 - Math.ceil(product.rating))].map((_, i) => (
                    <i key={i + Math.ceil(product.rating)} className="ri-star-line"></i>
                  ))}
                </div>
                <span className="text-sm text-gray-500 ml-1">({product.reviewCount})</span>
              </div>
            </div>
          </div>
        </Link>
      </div>

      {/* Product Detail Modal */}
      <ProductDetail 
        product={product}
        isOpen={isDetailOpen}
        onClose={() => setIsDetailOpen(false)}
      />
    </>
  );
};

export default ProductCard;
