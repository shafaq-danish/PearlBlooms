import { useState, useEffect } from "react";
import { formatCurrency } from "@/lib/utils";
import { Product } from "@/types";
import { useCart } from "@/hooks/useCart";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/hooks/use-toast";
import QuantitySelector from "@/components/ui/QuantitySelector";
import ImageGallery from "@/components/ui/ImageGallery";
import { Button } from "@/components/ui/button";

interface ProductDetailProps {
  product: Product;
  isOpen: boolean;
  onClose: () => void;
}

const ProductDetail = ({ product, isOpen, onClose }: ProductDetailProps) => {
  const [quantity, setQuantity] = useState(1);
  const [selectedVariant, setSelectedVariant] = useState<string | null>(null);
  const { addToCart } = useCart();
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    // Set default variant when product changes or modal opens
    if (isOpen && product.variants) {
      const variantType = Object.keys(product.variants)[0];
      if (variantType && product.variants[variantType]?.length) {
        setSelectedVariant(product.variants[variantType][0]);
      }
    }

    // Reset quantity
    setQuantity(1);

    // Prevent body scroll when modal is open
    if (isOpen) {
      document.body.classList.add("overflow-hidden");
    } else {
      document.body.classList.remove("overflow-hidden");
    }

    return () => {
      document.body.classList.remove("overflow-hidden");
    };
  }, [isOpen, product]);

  if (!isOpen) return null;

  const handleAddToCart = () => {
    if (!user) {
      toast({
        title: "Please login",
        description: "You need to be logged in to add items to your cart",
        variant: "destructive",
      });
      return;
    }

    addToCart(product.id, quantity, selectedVariant || undefined);
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart`,
    });
    onClose();
  };

  const handleBuyNow = () => {
    if (!user) {
      toast({
        title: "Please login",
        description: "You need to be logged in to purchase items",
        variant: "destructive",
      });
      return;
    }

    addToCart(product.id, quantity, selectedVariant || undefined);
    onClose();
    // In a real application, would redirect to checkout
    window.location.href = "/checkout";
  };

  const handleVariantSelect = (variant: string) => {
    setSelectedVariant(variant);
  };

  const getVariantType = (): string => {
    if (!product.variants) return "";
    return Object.keys(product.variants)[0] || "";
  };

  const getVariantOptions = (): string[] => {
    if (!product.variants) return [];
    const variantType = getVariantType();
    return product.variants[variantType] || [];
  };

  return (
    <div className="fixed inset-0 z-50 bg-black bg-opacity-75">
      <div className="relative w-full h-full flex items-center justify-center p-4">
        <div className="bg-white rounded-lg w-full max-w-4xl max-h-[90vh] overflow-y-auto custom-scrollbar">
          <div className="sticky top-0 bg-white z-10 flex justify-end p-4 border-b">
            <button
              onClick={onClose}
              className="text-black hover:text-gold"
              aria-label="Close"
            >
              <i className="ri-close-line text-2xl"></i>
            </button>
          </div>

          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <ImageGallery images={product.images} alt={product.name} />
              </div>

              <div>
                <h2 className="text-2xl font-serif font-bold mb-2">
                  {product.name}
                </h2>
                <div className="flex items-center mb-4">
                  <div className="flex text-gold">
                    {/* Show full stars */}
                    {[...Array(Math.floor(product.rating))].map((_, i) => (
                      <i key={i} className="ri-star-fill"></i>
                    ))}

                    {/* Show half star if needed */}
                    {product.rating % 1 >= 0.5 && (
                      <i className="ri-star-half-fill"></i>
                    )}

                    {/* Show empty stars */}
                    {[...Array(5 - Math.ceil(product.rating))].map((_, i) => (
                      <i
                        key={i + Math.ceil(product.rating)}
                        className="ri-star-line"
                      ></i>
                    ))}
                  </div>
                  <span className="text-sm text-gray-500 ml-2">
                    {product.reviewCount} reviews
                  </span>
                </div>

                <p className="text-2xl font-semibold mb-4">
                  {formatCurrency(product.price)}
                </p>

                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-500 mb-2">
                    Description
                  </h3>
                  <p className="text-gray-700">{product.description}</p>
                </div>

                {product.variants && getVariantOptions().length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-500 mb-2">
                      {getVariantType()}
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {getVariantOptions().map((variant, idx) => (
                        <button
                          key={idx}
                          className={`w-10 h-10 rounded-full border flex items-center justify-center transition-colors ${
                            selectedVariant === variant
                              ? "border-gold bg-gold-light text-gold font-medium"
                              : "border-gray-300 hover:border-gold"
                          }`}
                          onClick={() => handleVariantSelect(variant)}
                        >
                          {variant}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="mb-8">
                  <div className="flex items-center mb-4">
                    <QuantitySelector
                      quantity={quantity}
                      onIncrease={() => setQuantity(quantity + 1)}
                      onDecrease={() =>
                        setQuantity(Math.max(1, quantity - 1))
                      }
                      onQuantityChange={setQuantity}
                      max={product.stock}
                    />
                    <p className="text-sm text-gray-500 ml-4">
                      {product.stock <= 5
                        ? `Only ${product.stock} items left`
                        : "In stock"}
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <Button
                      className="w-full bg-gold hover:bg-gold-dark text-white font-medium py-3 px-4 rounded-lg transition-colors"
                      onClick={handleAddToCart}
                    >
                      Add to Cart
                    </Button>
                    <Button
                      className="w-full bg-black hover:bg-black-light text-white font-medium py-3 px-4 rounded-lg transition-colors"
                      onClick={handleBuyNow}
                    >
                      Buy Now
                    </Button>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center text-gray-700 hover:text-gold">
                      <i className="ri-truck-line mr-2"></i>
                      <span className="text-sm">Free shipping over $500</span>
                    </div>
                    <div className="flex items-center text-gray-700 hover:text-gold">
                      <i className="ri-shield-check-line mr-2"></i>
                      <span className="text-sm">Authenticity Guaranteed</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
