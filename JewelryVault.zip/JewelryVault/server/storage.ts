import { 
  users, type User, type InsertUser,
  products, type Product, type InsertProduct,
  categories, type Category, type InsertCategory,
  cartItems, type CartItem, type InsertCartItem,
  wishlistItems, type WishlistItem, type InsertWishlistItem,
  orders, type Order, type InsertOrder,
  testimonials, type Testimonial, type InsertTestimonial
} from "@shared/schema";

// Modify the interface with any CRUD methods
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  
  // Product methods
  getProduct(id: number): Promise<Product | undefined>;
  getProducts(options?: {
    categoryId?: number;
    featured?: boolean;
    new?: boolean;
    limit?: number;
    offset?: number;
    search?: string;
  }): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  
  // Category methods
  getCategory(id: number): Promise<Category | undefined>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  getCategories(): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Cart methods
  getCartItems(userId: number): Promise<CartItem[]>;
  getCartItem(id: number): Promise<CartItem | undefined>;
  getCartItemByProductAndUser(productId: number, userId: number): Promise<CartItem | undefined>;
  createCartItem(cartItem: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: number, cartItem: Partial<InsertCartItem>): Promise<CartItem | undefined>;
  deleteCartItem(id: number): Promise<boolean>;
  clearCart(userId: number): Promise<boolean>;
  
  // Wishlist methods
  getWishlistItems(userId: number): Promise<WishlistItem[]>;
  getWishlistItem(id: number): Promise<WishlistItem | undefined>;
  getWishlistItemByProductAndUser(productId: number, userId: number): Promise<WishlistItem | undefined>;
  createWishlistItem(wishlistItem: InsertWishlistItem): Promise<WishlistItem>;
  deleteWishlistItem(id: number): Promise<boolean>;
  
  // Order methods
  getOrder(id: number): Promise<Order | undefined>;
  getUserOrders(userId: number): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: number, status: string): Promise<Order | undefined>;
  
  // Testimonial methods
  getTestimonial(id: number): Promise<Testimonial | undefined>;
  getTestimonials(featured?: boolean): Promise<Testimonial[]>;
  createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private products: Map<number, Product>;
  private categories: Map<number, Category>;
  private cartItems: Map<number, CartItem>;
  private wishlistItems: Map<number, WishlistItem>;
  private orders: Map<number, Order>;
  private testimonials: Map<number, Testimonial>;
  
  userIdCounter: number;
  productIdCounter: number;
  categoryIdCounter: number;
  cartItemIdCounter: number;
  wishlistItemIdCounter: number;
  orderIdCounter: number;
  testimonialIdCounter: number;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.categories = new Map();
    this.cartItems = new Map();
    this.wishlistItems = new Map();
    this.orders = new Map();
    this.testimonials = new Map();
    
    this.userIdCounter = 1;
    this.productIdCounter = 1;
    this.categoryIdCounter = 1;
    this.cartItemIdCounter = 1;
    this.wishlistItemIdCounter = 1;
    this.orderIdCounter = 1;
    this.testimonialIdCounter = 1;
    
    // Initialize with seed data
    this.initializeData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { ...insertUser, id, createdAt: now };
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Product methods
  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProducts(options?: {
    categoryId?: number;
    featured?: boolean;
    new?: boolean;
    limit?: number;
    offset?: number;
    search?: string;
  }): Promise<Product[]> {
    let products = Array.from(this.products.values());
    
    if (options?.categoryId) {
      products = products.filter(p => p.categoryId === options.categoryId);
    }
    
    if (options?.featured !== undefined) {
      products = products.filter(p => p.featured === options.featured);
    }
    
    if (options?.new !== undefined) {
      products = products.filter(p => p.new === options.new);
    }
    
    if (options?.search) {
      const search = options.search.toLowerCase();
      products = products.filter(p => 
        p.name.toLowerCase().includes(search) || 
        p.description.toLowerCase().includes(search)
      );
    }
    
    // Sort by created date descending
    products.sort((a, b) => {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
    
    const offset = options?.offset || 0;
    const limit = options?.limit || products.length;
    
    return products.slice(offset, offset + limit);
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const id = this.productIdCounter++;
    const now = new Date();
    const newProduct: Product = { ...product, id, createdAt: now };
    this.products.set(id, newProduct);
    return newProduct;
  }
  
  async updateProduct(id: number, productData: Partial<InsertProduct>): Promise<Product | undefined> {
    const product = await this.getProduct(id);
    if (!product) return undefined;
    
    const updatedProduct = { ...product, ...productData };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }
  
  async deleteProduct(id: number): Promise<boolean> {
    return this.products.delete(id);
  }

  // Category methods
  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }
  
  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(
      (category) => category.slug === slug,
    );
  }

  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const id = this.categoryIdCounter++;
    const newCategory: Category = { ...category, id };
    this.categories.set(id, newCategory);
    return newCategory;
  }

  // Cart methods
  async getCartItems(userId: number): Promise<CartItem[]> {
    return Array.from(this.cartItems.values()).filter(
      (item) => item.userId === userId,
    );
  }
  
  async getCartItem(id: number): Promise<CartItem | undefined> {
    return this.cartItems.get(id);
  }
  
  async getCartItemByProductAndUser(productId: number, userId: number): Promise<CartItem | undefined> {
    return Array.from(this.cartItems.values()).find(
      (item) => item.productId === productId && item.userId === userId,
    );
  }

  async createCartItem(cartItem: InsertCartItem): Promise<CartItem> {
    const id = this.cartItemIdCounter++;
    const now = new Date();
    const newCartItem: CartItem = { ...cartItem, id, createdAt: now };
    this.cartItems.set(id, newCartItem);
    return newCartItem;
  }
  
  async updateCartItem(id: number, cartItemData: Partial<InsertCartItem>): Promise<CartItem | undefined> {
    const cartItem = await this.getCartItem(id);
    if (!cartItem) return undefined;
    
    const updatedCartItem = { ...cartItem, ...cartItemData };
    this.cartItems.set(id, updatedCartItem);
    return updatedCartItem;
  }
  
  async deleteCartItem(id: number): Promise<boolean> {
    return this.cartItems.delete(id);
  }
  
  async clearCart(userId: number): Promise<boolean> {
    const items = await this.getCartItems(userId);
    items.forEach(item => this.cartItems.delete(item.id));
    return true;
  }

  // Wishlist methods
  async getWishlistItems(userId: number): Promise<WishlistItem[]> {
    return Array.from(this.wishlistItems.values()).filter(
      (item) => item.userId === userId,
    );
  }
  
  async getWishlistItem(id: number): Promise<WishlistItem | undefined> {
    return this.wishlistItems.get(id);
  }
  
  async getWishlistItemByProductAndUser(productId: number, userId: number): Promise<WishlistItem | undefined> {
    return Array.from(this.wishlistItems.values()).find(
      (item) => item.productId === productId && item.userId === userId,
    );
  }

  async createWishlistItem(wishlistItem: InsertWishlistItem): Promise<WishlistItem> {
    const id = this.wishlistItemIdCounter++;
    const now = new Date();
    const newWishlistItem: WishlistItem = { ...wishlistItem, id, createdAt: now };
    this.wishlistItems.set(id, newWishlistItem);
    return newWishlistItem;
  }
  
  async deleteWishlistItem(id: number): Promise<boolean> {
    return this.wishlistItems.delete(id);
  }

  // Order methods
  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }
  
  async getUserOrders(userId: number): Promise<Order[]> {
    return Array.from(this.orders.values())
      .filter(order => order.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const id = this.orderIdCounter++;
    const now = new Date();
    const newOrder: Order = { ...order, id, createdAt: now };
    this.orders.set(id, newOrder);
    return newOrder;
  }
  
  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const order = await this.getOrder(id);
    if (!order) return undefined;
    
    const updatedOrder = { ...order, status };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }

  // Testimonial methods
  async getTestimonial(id: number): Promise<Testimonial | undefined> {
    return this.testimonials.get(id);
  }
  
  async getTestimonials(featured?: boolean): Promise<Testimonial[]> {
    let testimonials = Array.from(this.testimonials.values());
    
    if (featured !== undefined) {
      testimonials = testimonials.filter(t => t.featured === featured);
    }
    
    return testimonials;
  }

  async createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial> {
    const id = this.testimonialIdCounter++;
    const newTestimonial: Testimonial = { ...testimonial, id };
    this.testimonials.set(id, newTestimonial);
    return newTestimonial;
  }

  // Initialize with seed data
  private initializeData(): void {
    // Seed categories
    const categories: InsertCategory[] = [
      { name: "Rings", slug: "rings", image: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=600&h=800" },
      { name: "Necklaces", slug: "necklaces", image: "https://images.unsplash.com/photo-1602173574767-37ac01994b2a?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=600&h=800" },
      { name: "Earrings", slug: "earrings", image: "https://images.unsplash.com/photo-1574621100236-d25b64cfd647?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=600&h=800" },
      { name: "Bracelets", slug: "bracelets", image: "https://images.unsplash.com/photo-1611591437281-460bfbe1220a?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=600&h=800" }
    ];
    
    categories.forEach(category => {
      this.createCategory(category);
    });
    
    // Seed products
    const products: InsertProduct[] = [
      {
        name: "Diamond Solitaire Ring",
        description: "Elegantly crafted 18K yellow gold solitaire ring featuring a 0.8 carat round brilliant diamond. The minimalist design highlights the exceptional quality of the center stone, which has G color, VS1 clarity, and excellent cut.",
        price: 2499,
        categoryId: 1, // Rings
        images: [
          "https://pixabay.com/get/gabbaa8236dd87b397a5cb6874b34701b6cc5e2759c6c81703986f5bd5f8dfb41c9e3584044f42133b4aa6b74e0d58e3f41bd5f23c60011c9aa78fa6cd19eee39_1280.jpg",
          "https://images.unsplash.com/photo-1543294001-f7cd5d7fb516?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=600&h=600",
          "https://images.unsplash.com/photo-1605100804763-247f67b3557e?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=600&h=600"
        ],
        featured: true,
        new: true,
        rating: 4.5,
        reviewCount: 42,
        stock: 5,
        variants: { sizes: ["4", "4.5", "5", "5.5", "6", "6.5", "7", "7.5", "8"] }
      },
      {
        name: "Pearl Bloom Pendant Necklace",
        description: "Our signature 18K white gold pendant featuring a 10mm South Sea pearl nestled within delicate gold petals. The pendant is adorned with small brilliant diamonds and hangs from an 18-inch adjustable chain with a secure lobster clasp.",
        price: 1799,
        categoryId: 2, // Necklaces
        images: [
          "https://images.unsplash.com/photo-1611591437281-460bfbe1220a?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=600&h=600",
          "https://images.unsplash.com/photo-1602173574767-37ac01994b2a?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=600&h=600"
        ],
        featured: true,
        new: true,
        rating: 5.0,
        reviewCount: 28,
        stock: 3,
        variants: { chainLength: ["16\"", "18\"", "20\"", "24\""] }
      },
      {
        name: "Gold Hoop Earrings",
        description: "Classic 14K yellow gold hoop earrings with a 30mm diameter. These timeless hoops feature a hinged snap closure for secure and comfortable wear. The polished finish catches the light beautifully with every movement.",
        price: 899,
        categoryId: 3, // Earrings
        images: [
          "https://images.unsplash.com/photo-1589128777073-263566ae5e4d?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=600&h=600",
          "https://images.unsplash.com/photo-1574621100236-d25b64cfd647?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=600&h=600"
        ],
        featured: true,
        new: true,
        rating: 4.0,
        reviewCount: 36,
        stock: 8,
        variants: { color: ["Yellow Gold", "White Gold", "Rose Gold"] }
      },
      {
        name: "Diamond Tennis Bracelet",
        description: "Exquisite 18K white gold tennis bracelet featuring 3.0 carats of round brilliant diamonds in a four-prong setting. The bracelet measures 7 inches in length and secures with a double safety clasp.",
        price: 3299,
        categoryId: 4, // Bracelets
        images: [
          "https://images.unsplash.com/photo-1611591437281-460bfbe1220a?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=600&h=600"
        ],
        featured: true,
        new: false,
        rating: 4.8,
        reviewCount: 19,
        stock: 2,
        variants: { length: ["6.5\"", "7\"", "7.5\"", "8\""] }
      },
      {
        name: "Sapphire Stud Earrings",
        description: "Beautiful 14K white gold stud earrings featuring two round blue sapphires totaling 1.5 carats. The earrings are secured with screw backs for added safety.",
        price: 1299,
        categoryId: 3, // Earrings
        images: [
          "https://images.unsplash.com/photo-1574621100236-d25b64cfd647?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=600&h=600"
        ],
        featured: false,
        new: true,
        rating: 4.7,
        reviewCount: 24,
        stock: 6,
        variants: null
      },
      {
        name: "Pearl Strand Necklace",
        description: "Elegant 18-inch strand of 7-8mm freshwater cultured pearls with excellent luster. The necklace features a 14K white gold clasp and can be worn for both formal and casual occasions.",
        price: 799,
        categoryId: 2, // Necklaces
        images: [
          "https://images.unsplash.com/photo-1602173574767-37ac01994b2a?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=600&h=600"
        ],
        featured: false,
        new: false,
        rating: 4.2,
        reviewCount: 31,
        stock: 4,
        variants: { length: ["16\"", "18\"", "20\"", "24\""] }
      },
      {
        name: "Pearl and Diamond Floral Ring",
        description: "Stunning 14K rose gold ring featuring an 8mm white freshwater pearl center surrounded by a flower-inspired halo of round brilliant diamonds. The band is adorned with small diamond accents for added sparkle.",
        price: 1599,
        categoryId: 1, // Rings
        images: [
          "https://images.unsplash.com/photo-1605100804763-247f67b3557e?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=600&h=600",
          "https://images.unsplash.com/photo-1543294001-f7cd5d7fb516?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=600&h=600"
        ],
        featured: true,
        new: true,
        rating: 4.9,
        reviewCount: 17,
        stock: 3,
        variants: { sizes: ["5", "5.5", "6", "6.5", "7", "7.5", "8"] }
      },
      {
        name: "Akoya Pearl Stud Earrings",
        description: "Classic 14K yellow gold stud earrings featuring two 7mm AAA-quality Akoya pearls. These timeless studs have exceptional luster and come with secure screw-back closures.",
        price: 599,
        categoryId: 3, // Earrings
        images: [
          "https://images.unsplash.com/photo-1574621100236-d25b64cfd647?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=600&h=600"
        ],
        featured: false,
        new: true,
        rating: 4.6,
        reviewCount: 28,
        stock: 10,
        variants: { pearlSize: ["6mm", "7mm", "8mm", "9mm"] }
      },
      {
        name: "Pearl Tennis Bracelet",
        description: "Luxurious 18K white gold bracelet featuring fifteen 6mm perfectly matched freshwater pearls connected by small diamond-accented links. The bracelet measures 7 inches in length and secures with a double safety clasp.",
        price: 2499,
        categoryId: 4, // Bracelets
        images: [
          "https://images.unsplash.com/photo-1573408301606-9880df903830?ixlib=rb-4.0.3&auto=format&fit=crop&q=80&w=600&h=600"
        ],
        featured: true,
        new: true,
        rating: 4.8,
        reviewCount: 12,
        stock: 4,
        variants: { length: ["6.5\"", "7\"", "7.5\"", "8\""] }
      }
    ];
    
    products.forEach(product => {
      this.createProduct(product);
    });
    
    // Seed testimonials
    const testimonials: InsertTestimonial[] = [
      {
        name: "Emily Morgan",
        location: "San Francisco, CA",
        content: "The pendant necklace I purchased exceeded all expectations. The craftsmanship is exceptional, and it arrived in beautiful packaging. It's become my everyday favorite piece.",
        rating: 5,
        avatar: null,
        featured: true
      },
      {
        name: "James Kelly",
        location: "Boston, MA",
        content: "I purchased my engagement ring here after months of searching. The staff was incredibly helpful in guiding me through the selection process, and the final ring is absolutely stunning.",
        rating: 5,
        avatar: null,
        featured: true
      },
      {
        name: "Sophia Lee",
        location: "Chicago, IL",
        content: "The custom bracelet I ordered as an anniversary gift arrived earlier than expected and was even more beautiful in person. My wife was overjoyed with the unique design and quality.",
        rating: 4,
        avatar: null,
        featured: true
      }
    ];
    
    testimonials.forEach(testimonial => {
      this.createTestimonial(testimonial);
    });
  }
}

export const storage = new MemStorage();
